from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import (
    KeepTogether,
    PageBreak,
    Paragraph as ReportLabParagraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "public" / "samples"
OUTPUT.mkdir(parents=True, exist_ok=True)

INK = colors.HexColor("#10262D")
MUTED = colors.HexColor("#607276")
AQUA = colors.HexColor("#24786B")
ACID = colors.HexColor("#D9FF59")
ORANGE = colors.HexColor("#B54719")
PAPER = colors.HexColor("#F4F2EB")
LINE = colors.HexColor("#CCD4D2")
pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))

PDF_ZH = {
    "SAMPLE SERIES OVERVIEW / DATASET V1": "SAMPLE 系列概览 / 数据集 V1",
    "NX Series end-suction pump concept": "NX 系列端吸离心泵概念",
    "A fictional product-page support document for HVAC and clean-water industrial cooling. It demonstrates document hierarchy and evidence status; it is not a manufacturer brochure.": "面向 HVAC 与工业清水冷却的虚构产品页配套文档。用于展示文档层级与证据状态，并非制造商样本。",
    "USE BOUNDARY": "使用边界",
    "<b>50 Hz illustrative data only.</b> A 60 Hz request remains Engineering review. Final selection, NPSH margin, material compatibility, motor, dimensions and compliance require manufacturer evidence.": "<b>仅含 50 Hz 示意数据。</b>60 Hz 请求保持工程复核。最终选型、NPSH 裕量、材料兼容性、电机、尺寸与合规性均需制造商证据。",
    "Concept application envelope": "概念应用范围",
    "Included for the UX prototype": "UX 原型纳入范围",
    "Engineering review / excluded": "工程复核 / 排除",
    "HVAC chilled and condenser water": "HVAC 冷冻水与冷却水",
    "Fire-protection duty": "消防工况",
    "District energy circulation": "区域能源循环",
    "Potable-water certification": "饮用水认证",
    "Clean-water industrial cooling loops": "工业清水冷却循环",
    "Explosive atmosphere or aggressive chemicals": "爆炸性环境或强腐蚀性化学介质",
    "Known flow, head and temperature": "流量、扬程与温度已知",
    "Abrasive slurry or solids-laden service": "磨蚀性浆体或含固体介质",
    "Illustrative model register": "示意型号清单",
    "Model": "型号",
    "Speed": "转速",
    "Motor": "电机",
    "DN suction / discharge": "吸入口 / 排出口 DN",
    "POR flow": "POR 流量",
    "Evidence status": "证据状态",
    "Item": "项目",
    "Status": "状态",
    "Meaning": "含义",
    "Performance curves": "性能曲线",
    "Illustrative": "示意性",
    "Synthetic dataset created for interaction testing": "为交互测试创建的合成数据集",
    "Reference": "参考",
    "Design language only; no conformity claim": "仅作设计语言参考；不声称符合性",
    "ISO 9906 report": "ISO 9906 报告",
    "Not supplied": "未提供",
    "Test grade and report would require manufacturer evidence": "测试等级与报告需要制造商证据",
    "Market approvals": "市场准入",
    "No CE, UL, FM, NSF or ATEX badge is claimed": "未声称具有 CE、UL、FM、NSF 或 ATEX 标识",
    "AsterFlow and NX Series are fictional. This unsolicited portfolio concept is not an official project for CNP or any benchmark manufacturer.": "AsterFlow 与 NX Series 均为虚构。本自主作品集概念并非南方泵业或任何基准制造商的官方项目。",
    "SAMPLE MODEL DATASHEET / 50 HZ": "SAMPLE 型号数据表 / 50 HZ",
    "Illustrative typed data used by the AsterFlow NX product-page prototype. Values below are not certified manufacturer performance.": "AsterFlow NX 产品页原型使用的示意性类型化数据。以下数值并非经制造商认证的性能。",
    "GOLDEN TRACE": "黄金路径",
    "At 40 m3/h and 45 m required head, the concept curve interpolates 49.2 m head, 77% efficiency, 3.0 m NPSHr and 8.0 kW shaft power. Final selection remains subject to review.": "在 40 m3/h、所需扬程 45 m 的工况下，概念曲线插值得到 49.2 m 扬程、77% 效率、3.0 m NPSHr 与 8.0 kW 轴功率。最终选型仍须复核。",
    "Concept configuration": "概念配置",
    "Field": "字段",
    "Illustrative value": "示意值",
    "Arrangement": "结构形式",
    "Horizontal single-stage end-suction": "卧式单级端吸",
    "Concept": "概念",
    "Nominal impeller": "公称叶轮",
    "Speed / frequency": "转速 / 频率",
    "Curve dataset": "曲线数据集",
    "Suction / discharge": "吸入口 / 排出口",
    "Motor power": "电机功率",
    "Maximum working pressure": "最大工作压力",
    "Fluid temperature": "介质温度",
    "Illustrative curve data": "示意曲线数据",
    "Flow m3/h": "流量 m3/h",
    "Head m": "扬程 m",
    "Efficiency %": "效率 %",
    "Shaft power kW": "轴功率 kW",
    "NPSHr is a pump characteristic. NPSHa, the applicable margin and suction conditions must be reviewed for the real system. POR is model-specific and must be verified from manufacturer data.": "NPSHr 是泵的特性参数。真实系统的 NPSHa、适用裕量与吸入条件均须复核。POR 按型号定义，须以制造商数据核验。",
    "SAMPLE INSTALLATION DATA REQUEST": "SAMPLE 安装数据需求表",
    "Information needed before application review": "应用复核前所需信息",
    "A checklist showing what a real Technical RFQ should collect after a preliminary shortlist. Blank fields are acceptable when they are explicitly routed for engineering review.": "展示真实 Technical RFQ 在初步候选后应收集信息的清单。未知字段可留空，并明确进入工程复核。",
    "NO APPROVAL IMPLIED": "不代表批准",
    "Completing this checklist does not produce a certified selection or quotation. The AsterFlow prototype route validates data locally and persists nothing.": "完成本清单不会产生认证选型或报价。AsterFlow 原型仅在本地验证数据，且不保存任何内容。",
    "System and project checklist": "系统与项目清单",
    "Decision field": "决策字段",
    "Example / requested input": "示例 / 所需输入",
    "Why it matters": "重要性",
    "Duty point": "工况点",
    "Flow, head, frequency": "流量、扬程、频率",
    "Defines the operating requirement": "定义运行需求",
    "Fluid": "介质",
    "Composition, temperature, SG, viscosity": "成分、温度、比重、黏度",
    "Affects compatibility and performance": "影响兼容性与性能",
    "Suction": "吸入条件",
    "NPSHa, level, pressure, lift, piping": "NPSHa、液位、压力、吸上高度、管路",
    "Supports NPSH and cavitation review": "支持 NPSH 与汽蚀复核",
    "Solids": "固体",
    "Type, concentration, particle size": "类型、浓度、粒径",
    "May move service outside clean-water scope": "可能使工况超出清水范围",
    "Material / seal": "材料 / 密封",
    "Wetted material and seal preference": "过流材料与密封偏好",
    "Requires chemical and temperature review": "需要化学与温度复核",
    "Voltage, phase, enclosure, VFD": "电压、相数、防护形式、VFD",
    "Defines regional electrical configuration": "定义区域电气配置",
    "Installation": "安装",
    "Country, indoor/outdoor, altitude": "国家、室内/室外、海拔",
    "Affects motor and compliance requirements": "影响电机与合规要求",
    "Required standard, report or certificate": "要求的标准、报告或证书",
    "Prevents unsupported badge claims": "避免无证据的标识声明",
    "Project": "项目",
    "Quantity, stage, target date": "数量、阶段、目标日期",
    "Frames the technical quotation": "界定技术报价范围",
    "Attachment boundary in the prototype": "原型中的附件边界",
    "Rule": "规则",
    "Prototype behavior": "原型行为",
    "Count": "数量",
    "One attachment maximum": "最多 1 个附件",
    "Format": "格式",
    "PDF, JPEG or PNG": "PDF、JPEG 或 PNG",
    "Size": "大小",
    "10 MB maximum": "最大 10 MB",
    "Storage": "存储",
    "No bytes persisted; metadata only during validation": "不保存文件字节；验证时仅处理元数据",
    "SAMPLE / CONCEPT only. Do not use this document for procurement, installation, construction or engineering approval.": "仅供 SAMPLE / 概念展示。请勿用于采购、安装、施工或工程批准。",
}

styles = getSampleStyleSheet()
styles.add(
    ParagraphStyle(
        name="TableCellNX",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7.5,
        leading=10,
        textColor=INK,
    )
)
styles.add(
    ParagraphStyle(
        name="TableHeadNX",
        parent=styles["TableCellNX"],
        fontName="Helvetica-Bold",
        textColor=colors.white,
    )
)
styles.add(
    ParagraphStyle(
        name="Eyebrow",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8,
        leading=11,
        textColor=ORANGE,
        spaceAfter=6,
    )
)
styles.add(
    ParagraphStyle(
        name="TitleNX",
        parent=styles["Title"],
        fontName="Helvetica-Bold",
        fontSize=27,
        leading=30,
        textColor=INK,
        spaceAfter=11,
    )
)
styles.add(
    ParagraphStyle(
        name="LeadNX",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=11,
        leading=16,
        textColor=MUTED,
        spaceAfter=17,
    )
)
styles.add(
    ParagraphStyle(
        name="HeadingNX",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=15,
        leading=18,
        textColor=INK,
        spaceBefore=12,
        spaceAfter=8,
    )
)
styles.add(
    ParagraphStyle(
        name="BodyNX",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9,
        leading=13,
        textColor=INK,
        spaceAfter=7,
    )
)
styles.add(
    ParagraphStyle(
        name="SmallNX",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7.5,
        leading=10,
        textColor=MUTED,
    )
)
styles.add(
    ParagraphStyle(
        name="WatermarkNX",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=9,
        textColor=INK,
        alignment=TA_CENTER,
    )
)

def Paragraph(text, style):
    translation = PDF_ZH.get(text)
    if translation:
        text = (
            f"{text}<br/><font name='STSong-Light' size='8'>{translation}</font>"
        )
    return ReportLabParagraph(text, style)


def page(canvas, doc):
    canvas.saveState()
    width, height = A4
    canvas.setFillColor(INK)
    canvas.rect(0, height - 20 * mm, width, 20 * mm, fill=1, stroke=0)
    canvas.setFillColor(ACID)
    canvas.setFont("Helvetica-Bold", 10)
    canvas.drawString(18 * mm, height - 12.5 * mm, "ASTERFLOW / NX SERIES")
    canvas.setFillColor(colors.HexColor("#A9BDC0"))
    canvas.setFont("Helvetica", 7.5)
    canvas.drawRightString(width - 18 * mm, height - 12.5 * mm, "FICTIONAL PORTFOLIO CONCEPT")
    canvas.setFillColor(PAPER)
    canvas.rect(0, 0, width, 13 * mm, fill=1, stroke=0)
    canvas.setFillColor(MUTED)
    canvas.setFont("Helvetica", 7)
    canvas.drawString(18 * mm, 7 * mm, "Illustrative concept data - not for engineering selection.")
    canvas.setFont("STSong-Light", 6.5)
    canvas.drawString(18 * mm, 3.8 * mm, "示意性概念数据——不用于工程选型。")
    canvas.drawRightString(width - 18 * mm, 5 * mm, f"SAMPLE / page {doc.page}")
    canvas.setFillColor(colors.Color(0.71, 0.28, 0.10, alpha=0.08))
    canvas.setFont("Helvetica-Bold", 52)
    canvas.translate(width / 2, height / 2)
    canvas.rotate(34)
    canvas.drawCentredString(0, 0, "SAMPLE - CONCEPT")
    canvas.restoreState()


def table(rows, widths=None):
    rows = [
        [
            Paragraph(str(cell), styles["TableHeadNX" if row_index == 0 else "TableCellNX"])
            for cell in row
        ]
        for row_index, row in enumerate(rows)
    ]
    result = Table(rows, colWidths=widths, repeatRows=1, hAlign="LEFT")
    result.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), INK),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                ("FONTSIZE", (0, 0), (-1, -1), 7.5),
                ("LEADING", (0, 0), (-1, -1), 10),
                ("GRID", (0, 0), (-1, -1), 0.5, LINE),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PAPER]),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 7),
                ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    return result


def callout(title, body):
    block = Table(
        [[Paragraph(title, styles["Eyebrow"]), Paragraph(body, styles["BodyNX"])]],
        colWidths=[42 * mm, 120 * mm],
    )
    block.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), PAPER),
                ("BOX", (0, 0), (-1, -1), 0.8, ORANGE),
                ("LINEBEFORE", (0, 0), (0, 0), 4, ORANGE),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
                ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                ("TOPPADDING", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    return block


def document(path, story):
    doc = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        rightMargin=18 * mm,
        leftMargin=18 * mm,
        topMargin=29 * mm,
        bottomMargin=20 * mm,
        title=path.stem,
        author="AsterFlow portfolio concept",
        subject="Illustrative sample document",
    )
    doc.build(story, onFirstPage=page, onLaterPages=page)


overview = [
    Paragraph("SAMPLE SERIES OVERVIEW / DATASET V1", styles["Eyebrow"]),
    Paragraph("NX Series end-suction pump concept", styles["TitleNX"]),
    Paragraph(
        "A fictional product-page support document for HVAC and clean-water industrial cooling. "
        "It demonstrates document hierarchy and evidence status; it is not a manufacturer brochure.",
        styles["LeadNX"],
    ),
    callout(
        "USE BOUNDARY",
        "<b>50 Hz illustrative data only.</b> A 60 Hz request remains Engineering review. "
        "Final selection, NPSH margin, material compatibility, motor, dimensions and compliance require manufacturer evidence.",
    ),
    Paragraph("Concept application envelope", styles["HeadingNX"]),
    table(
        [
            ["Included for the UX prototype", "Engineering review / excluded"],
            ["HVAC chilled and condenser water", "Fire-protection duty"],
            ["District energy circulation", "Potable-water certification"],
            ["Clean-water industrial cooling loops", "Explosive atmosphere or aggressive chemicals"],
            ["Known flow, head and temperature", "Abrasive slurry or solids-laden service"],
        ],
        [82 * mm, 82 * mm],
    ),
    Paragraph("Illustrative model register", styles["HeadingNX"]),
    table(
        [
            ["Model", "Speed", "Motor", "DN suction / discharge", "POR flow"],
            ["NX 50-32-160", "2900 rpm", "5.5 kW", "50 / 32 mm", "21-29 m3/h"],
            ["NX 65-40-200", "2900 rpm", "11 kW", "65 / 40 mm", "34-47 m3/h"],
            ["NX 80-50-200", "2900 rpm", "15 kW", "80 / 50 mm", "51-70 m3/h"],
        ],
        [38 * mm, 27 * mm, 25 * mm, 43 * mm, 31 * mm],
    ),
    Paragraph("Evidence status", styles["HeadingNX"]),
    table(
        [
            ["Item", "Status", "Meaning"],
            ["Performance curves", "Illustrative", "Synthetic dataset created for interaction testing"],
            ["ISO 2858 / 5199", "Reference", "Design language only; no conformity claim"],
            ["ISO 9906 report", "Not supplied", "Test grade and report would require manufacturer evidence"],
            ["Market approvals", "Not supplied", "No CE, UL, FM, NSF or ATEX badge is claimed"],
        ],
        [42 * mm, 29 * mm, 93 * mm],
    ),
    Spacer(1, 9 * mm),
    Paragraph(
        "AsterFlow and NX Series are fictional. This unsolicited portfolio concept is not an official "
        "project for CNP or any benchmark manufacturer.",
        styles["SmallNX"],
    ),
]
document(OUTPUT / "AsterFlow_NX_Series_Overview_SAMPLE.pdf", overview)

curve_rows = [
    ["Flow m3/h", "Head m", "Efficiency %", "NPSHr m", "Shaft power kW"],
    ["0", "64.0", "0", "1.8", "3.2"],
    ["10", "62.5", "40", "1.9", "4.0"],
    ["20", "59.5", "59", "2.1", "5.3"],
    ["30", "55.0", "70", "2.5", "6.7"],
    ["40", "49.2", "77", "3.0", "8.0"],
    ["50", "42.0", "75", "3.8", "9.2"],
    ["60", "33.0", "66", "4.8", "10.2"],
    ["70", "22.5", "50", "6.0", "10.8"],
]
datasheet = [
    Paragraph("SAMPLE MODEL DATASHEET / 50 HZ", styles["Eyebrow"]),
    Paragraph("NX 65-40-200", styles["TitleNX"]),
    Paragraph(
        "Illustrative typed data used by the AsterFlow NX product-page prototype. "
        "Values below are not certified manufacturer performance.",
        styles["LeadNX"],
    ),
    callout(
        "GOLDEN TRACE",
        "At 40 m3/h and 45 m required head, the concept curve interpolates 49.2 m head, "
        "77% efficiency, 3.0 m NPSHr and 8.0 kW shaft power. Final selection remains subject to review.",
    ),
    Paragraph("Concept configuration", styles["HeadingNX"]),
    table(
        [
            ["Field", "Illustrative value", "Status"],
            ["Arrangement", "Horizontal single-stage end-suction", "Concept"],
            ["Nominal impeller", "200 mm", "Concept"],
            ["Speed / frequency", "2900 rpm / 50 Hz", "Curve dataset"],
            ["Suction / discharge", "DN 65 / DN 40", "Concept"],
            ["Motor power", "11 kW", "Concept"],
            ["Maximum working pressure", "16 bar", "Concept"],
            ["Fluid temperature", "-10 to 120 C", "Concept"],
            ["POR flow", "34 to 47 m3/h", "Illustrative"],
        ],
        [49 * mm, 71 * mm, 44 * mm],
    ),
    Paragraph("Illustrative curve data", styles["HeadingNX"]),
    table(curve_rows, [31 * mm, 31 * mm, 34 * mm, 31 * mm, 37 * mm]),
    Spacer(1, 7 * mm),
    Paragraph(
        "NPSHr is a pump characteristic. NPSHa, the applicable margin and suction conditions "
        "must be reviewed for the real system. POR is model-specific and must be verified from manufacturer data.",
        styles["SmallNX"],
    ),
]
document(OUTPUT / "AsterFlow_NX_65-40-200_Datasheet_SAMPLE.pdf", datasheet)

check_rows = [
    ["Decision field", "Example / requested input", "Why it matters"],
    ["Duty point", "Flow, head, frequency", "Defines the operating requirement"],
    ["Fluid", "Composition, temperature, SG, viscosity", "Affects compatibility and performance"],
    ["Suction", "NPSHa, level, pressure, lift, piping", "Supports NPSH and cavitation review"],
    ["Solids", "Type, concentration, particle size", "May move service outside clean-water scope"],
    ["Material / seal", "Wetted material and seal preference", "Requires chemical and temperature review"],
    ["Motor", "Voltage, phase, enclosure, VFD", "Defines regional electrical configuration"],
    ["Installation", "Country, indoor/outdoor, altitude", "Affects motor and compliance requirements"],
    ["Evidence", "Required standard, report or certificate", "Prevents unsupported badge claims"],
    ["Project", "Quantity, stage, target date", "Frames the technical quotation"],
]
request = [
    Paragraph("SAMPLE INSTALLATION DATA REQUEST", styles["Eyebrow"]),
    Paragraph("Information needed before application review", styles["TitleNX"]),
    Paragraph(
        "A checklist showing what a real Technical RFQ should collect after a preliminary shortlist. "
        "Blank fields are acceptable when they are explicitly routed for engineering review.",
        styles["LeadNX"],
    ),
    callout(
        "NO APPROVAL IMPLIED",
        "Completing this checklist does not produce a certified selection or quotation. "
        "The AsterFlow prototype route validates data locally and persists nothing.",
    ),
    Paragraph("System and project checklist", styles["HeadingNX"]),
    table(check_rows, [43 * mm, 61 * mm, 60 * mm]),
    Paragraph("Attachment boundary in the prototype", styles["HeadingNX"]),
    table(
        [
            ["Rule", "Prototype behavior"],
            ["Count", "One attachment maximum"],
            ["Format", "PDF, JPEG or PNG"],
            ["Size", "10 MB maximum"],
            ["Storage", "No bytes persisted; metadata only during validation"],
        ],
        [48 * mm, 116 * mm],
    ),
    Spacer(1, 8 * mm),
    Paragraph(
        "SAMPLE / CONCEPT only. Do not use this document for procurement, installation, construction or engineering approval.",
        styles["SmallNX"],
    ),
]
document(OUTPUT / "AsterFlow_NX_Installation_Request_SAMPLE.pdf", request)

for output in sorted(OUTPUT.glob("*.pdf")):
    print(f"{output.name}\t{output.stat().st_size} bytes")
