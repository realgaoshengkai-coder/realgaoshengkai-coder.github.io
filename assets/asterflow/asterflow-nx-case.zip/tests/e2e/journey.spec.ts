import AxeBuilder from "@axe-core/playwright";
import { expect, test } from "@playwright/test";

test("duty → shortlist → curve → RFQ → deterministic summary", async ({
  page,
}) => {
  const consoleErrors: string[] = [];
  page.on("console", (message) => {
    if (message.type() === "error") consoleErrors.push(message.text());
  });
  page.on("pageerror", (error) => consoleErrors.push(error.message));

  await page.goto("/");
  await expect(
    page
      .getByText("Illustrative concept data — not for engineering selection.", {
        exact: true,
      })
      .first(),
  ).toBeVisible();

  await page.locator("#selector-flow").fill("40");
  await page.locator("#selector-head").fill("45");
  await page.locator("#selector-frequency").selectOption("50");
  await page.locator("#selector-temperature").fill("20");
  await page
    .getByRole("button", { name: "Show preliminary shortlist" })
    .click();

  await expect(
    page.getByRole("heading", { name: "2 concept curves cover this duty." }),
  ).toBeVisible();
  await expect(
    page.getByText("NX 65-40-200", { exact: true }).first(),
  ).toBeVisible();
  await expect(
    page.locator("#shortlist").getByText("93.4", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "View curve" }).first().click();
  await expect(
    page.getByRole("heading", {
      name: "NX 65-40-200 at the selected duty.",
    }),
  ).toBeVisible();

  await page.getByRole("button", { name: "US 美制", exact: true }).click();
  await expect(page.locator("#selector-flow")).toHaveValue("176.11");
  await expect(
    page.getByText("147.64 ft", { exact: false }).first(),
  ).toBeVisible();
  await page.getByRole("button", { name: "Metric 公制", exact: true }).click();
  await expect(page.locator("#selector-flow")).toHaveValue("40");

  await page.getByRole("button", { name: "Add to RFQ" }).first().click();
  await expect(
    page.getByRole("heading", {
      name: "Send the decision context, not “Contact us”.",
    }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Continue" }).click();

  await page.getByLabel("Installation country *").fill("Germany");
  await page
    .getByLabel("Attach one technical file (PDF, JPEG or PNG · max 10 MB)")
    .setInputFiles({
      name: "duty-point.pdf",
      mimeType: "application/pdf",
      buffer: Buffer.from("%PDF-1.4 SAMPLE"),
    });
  await page.getByRole("button", { name: "Continue" }).click();

  await page.getByLabel("Name *").fill("Demo Buyer");
  await page.getByLabel("Company *").fill("Example Engineering");
  await page.getByLabel("Business email *").fill("buyer@example.test");
  await page.getByLabel("Country *").fill("Germany");
  await page
    .getByLabel(
      "I consent to this local prototype processing the entered data to generate a technical summary.",
    )
    .check();
  await page
    .getByRole("button", { name: "Generate technical summary" })
    .click();

  await expect(
    page.getByRole("heading", { name: "The technical context stayed intact." }),
  ).toBeVisible();
  await expect(page.locator("pre")).toContainText("NX 65-40-200");
  await expect(page.locator("pre")).toContainText("40 m³/h at 45 m");
  expect(consoleErrors).toEqual([]);
});

test("60 Hz returns Engineering review without a synthetic shortlist", async ({
  page,
}) => {
  await page.goto("/");
  await page.locator("#selector-frequency").selectOption("60");
  await page
    .getByRole("button", { name: "Show preliminary shortlist" })
    .click();
  await expect(
    page.getByText("MISSING FREQUENCY DATA", { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "No synthetic match was generated." }),
  ).toBeVisible();
  await expect(page.locator("#performance")).toHaveCount(0);
});

test("keyboard entry point and automated accessibility scan", async ({
  page,
}) => {
  await page.goto("/");
  await page.keyboard.press("Tab");
  await expect(
    page.getByRole("link", { name: "Skip to product content" }),
  ).toBeFocused();
  await page.keyboard.press("Enter");
  await expect(page).toHaveURL(/#main-content$/);

  const results = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
    .analyze();
  const serious = results.violations.filter((violation) =>
    ["serious", "critical"].includes(violation.impact || ""),
  );
  expect(serious).toEqual([]);
});

test("RFQ focuses the first missing required field", async ({ page }) => {
  await page.goto("/#rfq");
  await page.getByRole("button", { name: "Continue" }).click();
  await page.getByRole("button", { name: "Continue" }).click();
  await expect(page.getByLabel("Installation country *")).toBeFocused();
  await expect(
    page.getByText("Enter the installation country. / 请输入安装国家。", {
      exact: true,
    }),
  ).toBeVisible();
});

test("route rejects a tampered RFQ payload", async ({ request }) => {
  const response = await request.post("/api/rfq", {
    multipart: {
      payload: JSON.stringify({
        unitSystem: "metric",
        flow: -1,
        head: 45,
        frequencyHz: 50,
        fluid: "Water",
        temperature: 20,
        vfdRequired: false,
        quantity: 0,
        installationCountry: "",
        name: "X",
        company: "X",
        businessEmail: "tampered",
        contactCountry: "",
        consent: false,
      }),
    },
  });
  expect(response.status()).toBe(400);
  await expect(response.json()).resolves.toMatchObject({
    error: "RFQ validation failed. / RFQ 验证失败。",
  });
});

test("four bilingual chapters share one interactive 3D product", async ({
  page,
}) => {
  await page.goto("/");
  await expect(page.locator(".story-chapter")).toHaveCount(4);
  await expect(page.locator(".pump-stage canvas")).toHaveCount(1);
  await expect(page.locator('[lang="en"]')).not.toHaveCount(0);
  await expect(page.locator('[lang="zh-CN"]')).not.toHaveCount(0);
  await expect(
    page.getByRole("button", { name: "Auto rotate 自动旋转", exact: true }),
  ).toBeVisible();
  const chapterBackgrounds = await page
    .locator(".story-chapter")
    .evaluateAll((chapters) =>
      chapters.map((chapter) => getComputedStyle(chapter).backgroundColor),
    );
  expect(chapterBackgrounds).toEqual(Array(4).fill("rgba(0, 0, 0, 0)"));
});

test("decision trace links redline, units, rejection, counterfactual and RFQ state", async ({
  page,
}) => {
  await page.goto("/");
  await page.locator("#selector-flow").fill("40");
  await page.locator("#selector-head").fill("45");
  await page.locator("#selector-frequency").selectOption("50");
  await page.locator("#selector-temperature").fill("20");
  await page
    .getByRole("button", { name: "Show preliminary shortlist" })
    .click();

  await expect(page.locator(".pump-stage")).toHaveAttribute(
    "data-evidence-skin",
    "illustrative",
  );
  await expect(page.locator(".rejection-rail")).toBeVisible();
  await expect(page.locator(".tender-redline")).toBeVisible();

  await page
    .getByRole("button", { name: "Inspect unit pair 检查单位对应" })
    .click();
  await expect(page.locator(".parity-grid")).toBeVisible();

  await page
    .locator('[data-redline-state="caveat"]')
    .getByRole("button", { name: "Clarify 澄清" })
    .click();
  await expect(page.locator(".rfq-question-manifest")).toContainText(
    "Request the manufacturer curve",
  );

  await page
    .getByRole("button", { name: "Remove flow input 移除流量输入" })
    .click();
  await expect(page.locator(".pump-stage")).toHaveAttribute(
    "data-evidence-skin",
    "uncovered",
  );
  await expect(page.locator("#shortlist .shortlist-grid")).toHaveCount(0);
  await expect(page.locator(".counterfactual-impact")).toContainText(
    "Preliminary shortlist",
  );

  await page
    .getByRole("button", { name: "Restore entered duty 恢复已输入工况" })
    .click();
  await expect(page.locator(".pump-stage")).toHaveAttribute(
    "data-evidence-skin",
    "illustrative",
  );
  await expect(page.locator("#shortlist .shortlist-grid")).toBeVisible();
});

for (const viewport of [
  { width: 390, height: 844 },
  { width: 768, height: 1024 },
  { width: 1280, height: 800 },
  { width: 1440, height: 900 },
]) {
  test(`${viewport.width}x${viewport.height} has no page-level horizontal overflow`, async ({
    page,
  }) => {
    await page.setViewportSize(viewport);
    await page.goto("/");
    const overflow = await page.evaluate(
      () =>
        document.documentElement.scrollWidth -
        document.documentElement.clientWidth,
    );
    expect(overflow).toBeLessThanOrEqual(1);
    await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  });
}
