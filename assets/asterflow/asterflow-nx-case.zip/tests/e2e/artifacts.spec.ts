import { mkdir } from "node:fs/promises";
import path from "node:path";
import AxeBuilder from "@axe-core/playwright";
import { expect, test } from "@playwright/test";

const outputRoot = path.resolve(
  process.cwd(),
  "../../outputs/industrial-pump-case",
);
const screenshots = path.join(outputRoot, "screenshots");
const caseCards = path.join(outputRoot, "case-cards");

async function runSelection(page: import("@playwright/test").Page) {
  await page.locator("#selector-flow").fill("40");
  await page.locator("#selector-head").fill("45");
  await page.locator("#selector-frequency").selectOption("50");
  await page.locator("#selector-temperature").fill("20");
  await page
    .getByRole("button", { name: "Show preliminary shortlist" })
    .click();
  await expect(
    page.getByRole("heading", { name: "2 concept curves cover this duty." }),
  ).toBeVisible();
}

async function finishRfq(page: import("@playwright/test").Page) {
  await page.getByRole("button", { name: "Add to RFQ" }).first().click();
  await page.getByRole("button", { name: "Continue" }).click();
  await page.getByLabel("Installation country *").fill("Germany");
  await page.getByRole("button", { name: "Continue" }).click();
  await page.getByLabel("Name *").fill("Demo Buyer");
  await page.getByLabel("Company *").fill("Example Engineering");
  await page.getByLabel("Business email *").fill("buyer@example.test");
  await page.getByLabel("Country *").fill("Germany");
  await page
    .getByLabel(
      "I consent to this local prototype processing the entered data to generate a technical summary.",
    )
    .check();
  await page
    .getByRole("button", { name: "Generate technical summary" })
    .click();
  await expect(
    page.getByRole("heading", { name: "The technical context stayed intact." }),
  ).toBeVisible();
}

test("generate four deterministic product-story screenshots", async ({
  page,
}) => {
  await mkdir(screenshots, { recursive: true });
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto("/");
  await page.getByRole("button", { name: "Reset 复位", exact: true }).click();
  await page.screenshot({
    path: path.join(screenshots, "01-product-overview.png"),
  });

  await runSelection(page);
  await page.screenshot({
    path: path.join(screenshots, "02-duty-shortlist.png"),
  });

  await page.getByRole("button", { name: "View curve" }).first().click();
  await page.screenshot({
    path: path.join(screenshots, "03-performance-evidence.png"),
  });

  await finishRfq(page);
  await page.screenshot({
    path: path.join(screenshots, "04-technical-rfq.png"),
  });
});

test("generate seven 1080x1440 case evidence cards", async ({ page }) => {
  await mkdir(caseCards, { recursive: true });
  await page.setViewportSize({ width: 1080, height: 1440 });
  await page.goto("/case-study");
  const cards = page.locator(".case-card");
  await expect(cards).toHaveCount(7);
  const names = [
    "01-business-hook.png",
    "02-buyer-questions.png",
    "03-truth-contract.png",
    "04-selection-logic.png",
    "05-performance-view.png",
    "06-technical-rfq.png",
    "07-proof-positioning.png",
  ];
  for (let index = 0; index < names.length; index += 1) {
    await cards.nth(index).screenshot({
      path: path.join(caseCards, names[index]),
    });
  }
});

test("case page has no serious or critical automated accessibility issues", async ({
  page,
}) => {
  await page.goto("/case-study");
  const results = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
    .analyze();
  const serious = results.violations.filter((violation) =>
    ["serious", "critical"].includes(violation.impact || ""),
  );
  expect(serious).toEqual([]);
});
