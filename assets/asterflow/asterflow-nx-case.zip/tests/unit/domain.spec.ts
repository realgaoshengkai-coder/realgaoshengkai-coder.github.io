import { expect, test } from "@playwright/test";
import {
  buildRfqSummary,
  conversions,
  getPreliminaryShortlist,
  interpolateCurve,
  MAX_ATTACHMENT_BYTES,
  nxSeries,
  rfqSchema,
  validateAttachment,
} from "../../src/domain/pump";

const validRfq = {
  selectedModelId: "nx-65-40-200-50",
  unitSystem: "metric" as const,
  flow: 40,
  head: 45,
  frequencyHz: 50 as const,
  fluid: "Clean water",
  temperature: 20,
  vfdRequired: false,
  quantity: 1,
  installationCountry: "Germany",
  name: "Demo Buyer",
  company: "Example Engineering",
  businessEmail: "buyer@example.test",
  contactCountry: "Germany",
  consent: true,
};

test("unit conversions round-trip without changing canonical duty", () => {
  const metricFlow = 40;
  const metricHead = 45;
  expect(conversions.gpmToM3h(conversions.m3hToGpm(metricFlow))).toBeCloseTo(
    metricFlow,
    8,
  );
  expect(conversions.ftToM(conversions.mToFt(metricHead))).toBeCloseTo(
    metricHead,
    8,
  );
  expect(conversions.fToC(conversions.cToF(20))).toBeCloseTo(20, 8);
});

test("curve interpolation is deterministic at endpoints and between points", () => {
  const curve = nxSeries.productModels[1].curve;
  expect(interpolateCurve(curve, 0)).toEqual(curve[0]);
  expect(interpolateCurve(curve, 70)).toEqual(curve[curve.length - 1]);
  expect(interpolateCurve(curve, 35)).toMatchObject({
    flowM3h: 35,
    headM: 52.1,
    efficiencyPct: 73.5,
  });
  expect(interpolateCurve(curve, 71)).toBeUndefined();
});

test("40/45/50 trace excludes insufficient head and ranks eligible models", () => {
  const result = getPreliminaryShortlist({
    flow: 40,
    head: 45,
    temperature: 20,
    frequencyHz: 50,
    unitSystem: "metric",
  });
  expect(result.coverage).toBe("covered");
  expect(result.evaluations).toContainEqual(
    expect.objectContaining({
      modelId: "nx-50-32-160-50",
      eligibility: "insufficient-head",
    }),
  );
  expect(result.matches.map((match) => match.model.id)).toEqual([
    "nx-65-40-200-50",
    "nx-80-50-200-50",
  ]);
  expect(result.matches[0].score).toEqual({
    headMargin: 39.1,
    bepProximity: 35,
    efficiency: 19.3,
    total: 93.4,
  });
});

test("60 Hz fails closed and an out-of-range flow requests review", () => {
  const sixtyHz = getPreliminaryShortlist({
    flow: 40,
    head: 45,
    temperature: 20,
    frequencyHz: 60,
    unitSystem: "metric",
  });
  expect(sixtyHz.coverage).toBe("missing-frequency");
  expect(sixtyHz.matches).toEqual([]);

  const outside = getPreliminaryShortlist({
    flow: 200,
    head: 20,
    temperature: 20,
    frequencyHz: 50,
    unitSystem: "metric",
  });
  expect(outside.coverage).toBe("curve-out-of-range");
  expect(outside.matches).toEqual([]);
});

test("RFQ schema and attachment boundary reject tampered inputs", () => {
  expect(rfqSchema.safeParse(validRfq).success).toBe(true);
  expect(
    rfqSchema.safeParse({
      ...validRfq,
      quantity: 0,
      businessEmail: "not-an-email",
      consent: false,
    }).success,
  ).toBe(false);
  expect(
    validateAttachment({
      name: "system.exe",
      type: "application/octet-stream",
      size: 10,
    }),
  ).toContain("PDF");
  expect(
    validateAttachment({
      name: "system.pdf",
      type: "application/pdf",
      size: MAX_ATTACHMENT_BYTES + 1,
    }),
  ).toContain("10 MB");
});

test("success summary is deterministic and excludes direct contact fields", () => {
  const parsed = rfqSchema.parse(validRfq);
  const first = buildRfqSummary(parsed);
  const second = buildRfqSummary(parsed);
  expect(first).toBe(second);
  expect(first).toContain("NX 65-40-200");
  expect(first).toContain("40 m³/h at 45 m");
  expect(first).not.toContain(validRfq.businessEmail);
  expect(first).not.toContain(validRfq.name);
});
