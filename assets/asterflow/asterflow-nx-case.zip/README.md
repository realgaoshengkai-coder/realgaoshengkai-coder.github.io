# AsterFlow NX Series

Interactive portfolio concept for a fictional end-suction centrifugal pump
product page. It turns a clean-water HVAC / industrial-cooling duty point into
a preliminary shortlist, an inspectable 50 Hz performance view, and a
three-step Technical RFQ.

## Truth boundary

- AsterFlow and NX Series are fictional.
- All performance values are illustrative concept data, not engineering data.
- Dataset v1 contains 50 Hz curves only. A 60 Hz request stops at
  **Engineering review** and never synthesizes a curve or shortlist.
- Standards are reference context, not conformity or certification claims.
- The CNP page in the source register is an information-architecture benchmark
  only; this is not an official project for CNP or another manufacturer.
- The prototype makes no claim about real pump selection, quotation, lead time,
  procurement suitability, or inquiry growth.
- The RFQ demo stores nothing, sends no email, and discards attachment bytes.

## Included surfaces

- `/` — product story, application fit, duty-point selector, preliminary
  shortlist, performance curves, construction/configuration evidence, SAMPLE
  downloads, and three-step Technical RFQ.
- `/case-study` — seven-card evidence flow connecting the commercial problem,
  truth contract, selection policy, interface decisions, and proof boundary.
- `/api/rfq` — local demonstration route that revalidates the RFQ schema and
  returns a deterministic plain-text summary.

## Run locally

```bash
npm ci
npm run dev
```

Open <http://localhost:3000>.

Production check:

```bash
npm run verify
npm run artifacts
npm audit
```

## Selection policy v1

1. Exclude curves that do not cover requested flow, exceed their illustrative
   temperature boundary, or do not provide the requested head.
2. Score only eligible models:
   - head margin: 40 points, with 10% as the illustrative target;
   - proximity to BEP: 35 points;
   - interpolated efficiency: 25 points.
3. Sort by total score descending, then BEP distance ascending, then lexical
   model ID. Return no more than three results.
4. Keep final duty, NPSH margin, materials, motor/electrical configuration, and
   compliance under manufacturer/application-engineering review.

For the regression duty `40 m³/h · 45 m · 50 Hz · 20 °C`, the expected top
concept result is `NX 65-40-200` with an illustrative score of `93.4`.

## Project map

```text
src/domain/pump.ts                 typed dataset, conversions, shortlist policy, RFQ schema
src/features/nx-series/            product, selector, performance, and RFQ interface
src/app/api/rfq/route.ts           local validation-only RFQ endpoint
src/app/case-study/page.tsx        seven-card case evidence flow
public/samples/                    watermarked SAMPLE PDFs
research/source-register.json      dated source register
research/claim-ledger.json         claim-to-evidence status
research/decisions/                accepted scope and selection decisions
tests/unit/                        deterministic domain checks
tests/e2e/                         journey, responsive, tampering, and accessibility checks
```

## Reference register

The dated source register links the relevant ISO abstracts, Hydraulic Institute
operating-region explanation, WCAG overview, framework/testing documentation,
and the benchmark product page. Synthetic product values remain isolated in
`src/domain/pump.ts`.
