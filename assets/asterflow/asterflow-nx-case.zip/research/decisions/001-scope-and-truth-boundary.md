# ADR 001 — Scope and truth boundary

**Status:** Accepted · **Date:** 2026-07-29

Build one fictional AsterFlow NX product page for clean-water HVAC and industrial cooling duty. The page is an unsolicited portfolio concept, not a CNP or other reference-brand project.

All performance data is synthetic and labelled “Illustrative concept data — not for engineering selection.” Standards are references, not certification claims. Price, stock, lead time, customer proof, sales uplift and real engineering approval are outside scope.

The CNP public page informs a dated structural audit only. Its logo, imagery, copy, documents, badges and contacts do not enter the product experience.
