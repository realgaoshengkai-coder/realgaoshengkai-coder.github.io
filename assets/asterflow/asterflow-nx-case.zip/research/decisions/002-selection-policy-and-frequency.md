# ADR 002 — Selection policy v1 and frequency coverage

**Status:** Accepted · **Date:** 2026-07-29

The preliminary shortlist first excludes models whose curve does not cover the flow, whose temperature range is exceeded, or whose interpolated head is below the requested head.

Eligible models receive an illustrative score:

- Head margin: 40 points; 10% margin is the target.
- Relative distance from BEP: 35 points; 50% distance reaches zero.
- Interpolated efficiency: 25 points.

Tie-break: total descending, BEP distance ascending, model ID lexical. Results are capped at three.

Dataset v1 contains 50 Hz curves only. A 60 Hz request returns `missing-frequency` and Engineering review; no affinity-law or relabelled curve is synthesized.
