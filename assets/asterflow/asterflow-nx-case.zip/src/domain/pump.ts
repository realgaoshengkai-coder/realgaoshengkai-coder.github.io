import { z } from "zod";

export type UnitSystem = "metric" | "us";
export type FrequencyHz = 50 | 60;
export type EvidenceStatus = "illustrative" | "verified" | "unverified";
export type EvidenceType =
  | "standard_reference"
  | "engineering_explanation"
  | "illustrative_concept";

export interface Evidence {
  source: string;
  status: EvidenceStatus;
  evidenceType: EvidenceType;
  createdAt?: string;
  note: string;
}

export interface CurvePoint {
  flowM3h: number;
  headM: number;
  efficiencyPct: number;
  npshrM: number;
  shaftPowerKw: number;
}

export interface PumpModel {
  id: string;
  model: string;
  frequencyHz: 50;
  speedRpm: number;
  suctionDnMm: number;
  dischargeDnMm: number;
  nominalImpellerMm: number;
  motorPowerKw: number;
  maxWorkingPressureBar: number;
  liquidTemperatureC: { min: number; max: number };
  materials: string[];
  curve: CurvePoint[];
  operatingRegion: {
    bepFlowM3h: number;
    bepHeadM: number;
    porMinFlowM3h: number;
    porMaxFlowM3h: number;
    aorMinFlowM3h: number;
    aorMaxFlowM3h: number;
    evidence: Evidence;
  };
  evidence: Evidence;
}

const illustrativeEvidence: Evidence = {
  source: "Synthetic AsterFlow NX dataset v1",
  status: "illustrative",
  evidenceType: "illustrative_concept",
  createdAt: "2026-07-29",
  note: "Portfolio concept data; not derived from a certified manufacturer curve.",
};

export const nxSeries = {
  id: "nx-series",
  datasetId: "asterflow-nx-series",
  version: "1.0.0",
  brand: "AsterFlow",
  name: "NX Series",
  applications: [
    "HVAC chilled-water circulation",
    "Condenser-water circulation",
    "District energy circulation",
    "Clean-water industrial cooling loops",
  ],
  excludedApplications: [
    "Fire-protection duty",
    "Potable-water duty requiring material certification",
    "Explosive atmospheres",
    "Abrasive slurry or solids-laden service",
    "Aggressive chemicals without material and seal review",
  ],
  evidence: illustrativeEvidence,
  productModels: [
    {
      id: "nx-50-32-160-50",
      model: "NX 50-32-160",
      frequencyHz: 50,
      speedRpm: 2900,
      suctionDnMm: 50,
      dischargeDnMm: 32,
      nominalImpellerMm: 160,
      motorPowerKw: 5.5,
      maxWorkingPressureBar: 16,
      liquidTemperatureC: { min: -10, max: 120 },
      materials: ["Cast iron concept", "Stainless steel concept"],
      curve: [
        {
          flowM3h: 0,
          headM: 43,
          efficiencyPct: 0,
          npshrM: 1.5,
          shaftPowerKw: 1.7,
        },
        {
          flowM3h: 5,
          headM: 42.5,
          efficiencyPct: 32,
          npshrM: 1.6,
          shaftPowerKw: 2,
        },
        {
          flowM3h: 10,
          headM: 41.2,
          efficiencyPct: 50,
          npshrM: 1.7,
          shaftPowerKw: 2.5,
        },
        {
          flowM3h: 15,
          headM: 39.3,
          efficiencyPct: 63,
          npshrM: 1.9,
          shaftPowerKw: 3,
        },
        {
          flowM3h: 20,
          headM: 36.8,
          efficiencyPct: 71,
          npshrM: 2.2,
          shaftPowerKw: 3.5,
        },
        {
          flowM3h: 25,
          headM: 33.8,
          efficiencyPct: 75,
          npshrM: 2.7,
          shaftPowerKw: 4,
        },
        {
          flowM3h: 30,
          headM: 30,
          efficiencyPct: 73,
          npshrM: 3.3,
          shaftPowerKw: 4.4,
        },
        {
          flowM3h: 35,
          headM: 25.4,
          efficiencyPct: 65,
          npshrM: 4.1,
          shaftPowerKw: 4.8,
        },
        {
          flowM3h: 40,
          headM: 19.5,
          efficiencyPct: 49,
          npshrM: 5.2,
          shaftPowerKw: 5.1,
        },
      ],
      operatingRegion: {
        bepFlowM3h: 25,
        bepHeadM: 33.8,
        porMinFlowM3h: 21,
        porMaxFlowM3h: 29,
        aorMinFlowM3h: 15,
        aorMaxFlowM3h: 35,
        evidence: illustrativeEvidence,
      },
      evidence: illustrativeEvidence,
    },
    {
      id: "nx-65-40-200-50",
      model: "NX 65-40-200",
      frequencyHz: 50,
      speedRpm: 2900,
      suctionDnMm: 65,
      dischargeDnMm: 40,
      nominalImpellerMm: 200,
      motorPowerKw: 11,
      maxWorkingPressureBar: 16,
      liquidTemperatureC: { min: -10, max: 120 },
      materials: ["Cast iron concept", "Stainless steel concept"],
      curve: [
        {
          flowM3h: 0,
          headM: 64,
          efficiencyPct: 0,
          npshrM: 1.8,
          shaftPowerKw: 3.2,
        },
        {
          flowM3h: 10,
          headM: 62.5,
          efficiencyPct: 40,
          npshrM: 1.9,
          shaftPowerKw: 4,
        },
        {
          flowM3h: 20,
          headM: 59.5,
          efficiencyPct: 59,
          npshrM: 2.1,
          shaftPowerKw: 5.3,
        },
        {
          flowM3h: 30,
          headM: 55,
          efficiencyPct: 70,
          npshrM: 2.5,
          shaftPowerKw: 6.7,
        },
        {
          flowM3h: 40,
          headM: 49.2,
          efficiencyPct: 77,
          npshrM: 3,
          shaftPowerKw: 8,
        },
        {
          flowM3h: 50,
          headM: 42,
          efficiencyPct: 75,
          npshrM: 3.8,
          shaftPowerKw: 9.2,
        },
        {
          flowM3h: 60,
          headM: 33,
          efficiencyPct: 66,
          npshrM: 4.8,
          shaftPowerKw: 10.2,
        },
        {
          flowM3h: 70,
          headM: 22.5,
          efficiencyPct: 50,
          npshrM: 6,
          shaftPowerKw: 10.8,
        },
      ],
      operatingRegion: {
        bepFlowM3h: 40,
        bepHeadM: 49.2,
        porMinFlowM3h: 34,
        porMaxFlowM3h: 47,
        aorMinFlowM3h: 25,
        aorMaxFlowM3h: 58,
        evidence: illustrativeEvidence,
      },
      evidence: illustrativeEvidence,
    },
    {
      id: "nx-80-50-200-50",
      model: "NX 80-50-200",
      frequencyHz: 50,
      speedRpm: 2900,
      suctionDnMm: 80,
      dischargeDnMm: 50,
      nominalImpellerMm: 200,
      motorPowerKw: 15,
      maxWorkingPressureBar: 16,
      liquidTemperatureC: { min: -10, max: 120 },
      materials: ["Cast iron concept", "Stainless steel concept"],
      curve: [
        { flowM3h: 0, headM: 62, efficiencyPct: 0, npshrM: 2, shaftPowerKw: 4 },
        {
          flowM3h: 15,
          headM: 60.7,
          efficiencyPct: 43,
          npshrM: 2.1,
          shaftPowerKw: 5,
        },
        {
          flowM3h: 30,
          headM: 57.5,
          efficiencyPct: 62,
          npshrM: 2.4,
          shaftPowerKw: 6.7,
        },
        {
          flowM3h: 45,
          headM: 52.5,
          efficiencyPct: 73,
          npshrM: 2.9,
          shaftPowerKw: 8.5,
        },
        {
          flowM3h: 60,
          headM: 46,
          efficiencyPct: 80,
          npshrM: 3.5,
          shaftPowerKw: 10.3,
        },
        {
          flowM3h: 75,
          headM: 37.8,
          efficiencyPct: 77,
          npshrM: 4.4,
          shaftPowerKw: 12,
        },
        {
          flowM3h: 90,
          headM: 28,
          efficiencyPct: 68,
          npshrM: 5.6,
          shaftPowerKw: 13.4,
        },
        {
          flowM3h: 105,
          headM: 16.5,
          efficiencyPct: 52,
          npshrM: 7,
          shaftPowerKw: 14.2,
        },
      ],
      operatingRegion: {
        bepFlowM3h: 60,
        bepHeadM: 46,
        porMinFlowM3h: 51,
        porMaxFlowM3h: 70,
        aorMinFlowM3h: 38,
        aorMaxFlowM3h: 88,
        evidence: illustrativeEvidence,
      },
      evidence: illustrativeEvidence,
    },
  ] satisfies PumpModel[],
};

export const conversions = {
  m3hToGpm: (value: number) => value * 4.4028675,
  gpmToM3h: (value: number) => value / 4.4028675,
  mToFt: (value: number) => value * 3.280839895,
  ftToM: (value: number) => value / 3.280839895,
  kwToHp: (value: number) => value * 1.34102209,
  hpToKw: (value: number) => value / 1.34102209,
  barToPsi: (value: number) => value * 14.5037738,
  psiToBar: (value: number) => value / 14.5037738,
  cToF: (value: number) => value * 1.8 + 32,
  fToC: (value: number) => (value - 32) / 1.8,
};

export const round = (value: number, digits = 1) =>
  Number(value.toFixed(digits));

export interface DisplayDuty {
  flow: number;
  head: number;
  temperature: number;
  frequencyHz: FrequencyHz;
  unitSystem: UnitSystem;
}

export interface MetricDuty {
  flowM3h: number;
  headM: number;
  temperatureC: number;
  frequencyHz: FrequencyHz;
}

export function toMetricDuty(duty: DisplayDuty): MetricDuty {
  return {
    flowM3h:
      duty.unitSystem === "metric"
        ? duty.flow
        : conversions.gpmToM3h(duty.flow),
    headM:
      duty.unitSystem === "metric" ? duty.head : conversions.ftToM(duty.head),
    temperatureC:
      duty.unitSystem === "metric"
        ? duty.temperature
        : conversions.fToC(duty.temperature),
    frequencyHz: duty.frequencyHz,
  };
}

export function convertDuty(
  duty: DisplayDuty,
  unitSystem: UnitSystem,
): DisplayDuty {
  if (duty.unitSystem === unitSystem) return duty;
  const metric = toMetricDuty(duty);
  return unitSystem === "metric"
    ? {
        flow: round(metric.flowM3h, 2),
        head: round(metric.headM, 2),
        temperature: round(metric.temperatureC, 1),
        frequencyHz: metric.frequencyHz,
        unitSystem,
      }
    : {
        flow: round(conversions.m3hToGpm(metric.flowM3h), 2),
        head: round(conversions.mToFt(metric.headM), 2),
        temperature: round(conversions.cToF(metric.temperatureC), 1),
        frequencyHz: metric.frequencyHz,
        unitSystem,
      };
}

export function fromMetricDuty(
  duty: MetricDuty,
  unitSystem: UnitSystem,
): DisplayDuty {
  return unitSystem === "metric"
    ? {
        flow: round(duty.flowM3h, 2),
        head: round(duty.headM, 2),
        temperature: round(duty.temperatureC, 1),
        frequencyHz: duty.frequencyHz,
        unitSystem,
      }
    : {
        flow: round(conversions.m3hToGpm(duty.flowM3h), 2),
        head: round(conversions.mToFt(duty.headM), 2),
        temperature: round(conversions.cToF(duty.temperatureC), 1),
        frequencyHz: duty.frequencyHz,
        unitSystem,
      };
}

export function interpolateCurve(
  curve: CurvePoint[],
  flowM3h: number,
): CurvePoint | undefined {
  if (!Number.isFinite(flowM3h) || curve.length === 0) return undefined;
  if (flowM3h < curve[0].flowM3h || flowM3h > curve[curve.length - 1].flowM3h) {
    return undefined;
  }
  const exact = curve.find((point) => point.flowM3h === flowM3h);
  if (exact) return exact;
  const upperIndex = curve.findIndex((point) => point.flowM3h > flowM3h);
  const lower = curve[upperIndex - 1];
  const upper = curve[upperIndex];
  const ratio = (flowM3h - lower.flowM3h) / (upper.flowM3h - lower.flowM3h);
  const between = (a: number, b: number) => a + (b - a) * ratio;
  return {
    flowM3h,
    headM: between(lower.headM, upper.headM),
    efficiencyPct: between(lower.efficiencyPct, upper.efficiencyPct),
    npshrM: between(lower.npshrM, upper.npshrM),
    shaftPowerKw: between(lower.shaftPowerKw, upper.shaftPowerKw),
  };
}

export type Eligibility =
  | "eligible"
  | "insufficient-head"
  | "temperature-out-of-range"
  | "curve-out-of-range";

export interface ModelEvaluation {
  modelId: string;
  eligibility: Eligibility;
  point?: CurvePoint;
}

export function evaluateModel(
  model: PumpModel,
  duty: MetricDuty,
): ModelEvaluation {
  const point = interpolateCurve(model.curve, duty.flowM3h);
  if (!point) return { modelId: model.id, eligibility: "curve-out-of-range" };
  if (
    duty.temperatureC < model.liquidTemperatureC.min ||
    duty.temperatureC > model.liquidTemperatureC.max
  ) {
    return {
      modelId: model.id,
      eligibility: "temperature-out-of-range",
      point,
    };
  }
  if (point.headM < duty.headM) {
    return { modelId: model.id, eligibility: "insufficient-head", point };
  }
  return { modelId: model.id, eligibility: "eligible", point };
}

export type MatchState =
  | "within-illustrative-por"
  | "near-illustrative-por-boundary"
  | "engineering-review";

export interface Match {
  model: PumpModel;
  point: CurvePoint;
  matchState: MatchState;
  relativeBepDistance: number;
  score: {
    headMargin: number;
    bepProximity: number;
    efficiency: number;
    total: number;
  };
  warnings: string[];
}

export interface ShortlistOutcome {
  coverage: "covered" | "missing-frequency" | "curve-out-of-range";
  dutyMetric: MetricDuty;
  matches: Match[];
  evaluations: ModelEvaluation[];
  reviewReasons: string[];
}

const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));

export function getPreliminaryShortlist(
  displayDuty: DisplayDuty,
): ShortlistOutcome {
  const duty = toMetricDuty(displayDuty);
  if (duty.frequencyHz === 60) {
    return {
      coverage: "missing-frequency",
      dutyMetric: duty,
      matches: [],
      evaluations: [],
      reviewReasons: [
        "The concept dataset contains 50 Hz curves only.",
        "A 60 Hz curve must be supplied and reviewed by application engineering.",
      ],
    };
  }

  const evaluations = nxSeries.productModels.map((model) =>
    evaluateModel(model, duty),
  );
  const eligible = evaluations
    .filter(
      (evaluation): evaluation is ModelEvaluation & { point: CurvePoint } =>
        evaluation.eligibility === "eligible" && Boolean(evaluation.point),
    )
    .map((evaluation): Match => {
      const model = nxSeries.productModels.find(
        (candidate) => candidate.id === evaluation.modelId,
      ) as PumpModel;
      const point = evaluation.point;
      const marginRatio = (point.headM - duty.headM) / duty.headM;
      const relativeBepDistance =
        Math.abs(duty.flowM3h - model.operatingRegion.bepFlowM3h) /
        model.operatingRegion.bepFlowM3h;
      const headMargin = clamp(
        40 * Math.max(0, 1 - Math.abs(marginRatio - 0.1) / 0.3),
        0,
        40,
      );
      const bepProximity = clamp(
        35 * Math.max(0, 1 - relativeBepDistance / 0.5),
        0,
        35,
      );
      const efficiency = clamp((point.efficiencyPct / 100) * 25, 0, 25);
      const inPor =
        duty.flowM3h >= model.operatingRegion.porMinFlowM3h &&
        duty.flowM3h <= model.operatingRegion.porMaxFlowM3h;
      const inAor =
        duty.flowM3h >= model.operatingRegion.aorMinFlowM3h &&
        duty.flowM3h <= model.operatingRegion.aorMaxFlowM3h;
      const matchState: MatchState = inPor
        ? "within-illustrative-por"
        : inAor
          ? "near-illustrative-por-boundary"
          : "engineering-review";
      return {
        model,
        point,
        matchState,
        relativeBepDistance,
        score: {
          headMargin: round(headMargin),
          bepProximity: round(bepProximity),
          efficiency: round(efficiency),
          total: round(headMargin + bepProximity + efficiency),
        },
        warnings:
          matchState === "within-illustrative-por"
            ? ["Verify final duty and manufacturer curve."]
            : [
                "Duty is outside the illustrative POR.",
                "Application engineering review is required.",
              ],
      };
    })
    .sort(
      (a, b) =>
        b.score.total - a.score.total ||
        a.relativeBepDistance - b.relativeBepDistance ||
        a.model.id.localeCompare(b.model.id),
    )
    .slice(0, 3);

  const allOutOfRange = evaluations.every(
    (evaluation) => evaluation.eligibility === "curve-out-of-range",
  );
  return {
    coverage: allOutOfRange ? "curve-out-of-range" : "covered",
    dutyMetric: duty,
    matches: eligible,
    evaluations,
    reviewReasons:
      eligible.length > 0
        ? []
        : [
            allOutOfRange
              ? "Flow is outside every illustrative curve."
              : "No 50 Hz concept curve provides the requested head at this flow.",
            "Send the duty point for application engineering review.",
          ],
  };
}

export const rfqSchema = z.object({
  selectedModelId: z.string().trim().optional(),
  unitSystem: z.enum(["metric", "us"]),
  flow: z
    .number()
    .finite()
    .positive("Enter a flow greater than 0. / 请输入大于 0 的流量。"),
  head: z
    .number()
    .finite()
    .positive("Enter a head greater than 0. / 请输入大于 0 的扬程。"),
  frequencyHz: z.union([z.literal(50), z.literal(60)]),
  fluid: z
    .string()
    .trim()
    .min(2, "Enter the circulating fluid. / 请输入循环介质。"),
  temperature: z.number().finite(),
  npsha: z.number().finite().nonnegative().optional(),
  suctionCondition: z.string().trim().optional(),
  specificGravity: z.number().finite().positive().optional(),
  viscosityCst: z.number().finite().positive().optional(),
  solidsPct: z.number().finite().min(0).max(100).optional(),
  materialPreference: z.string().trim().optional(),
  sealPreference: z.string().trim().optional(),
  voltageV: z.number().int().positive().optional(),
  phase: z.union([z.literal(1), z.literal(3)]).optional(),
  motorEnclosure: z.string().trim().optional(),
  vfdRequired: z.boolean(),
  quantity: z
    .number()
    .int()
    .min(1, "Quantity must be at least 1. / 数量至少为 1。"),
  requiredStandards: z.string().trim().optional(),
  reviewQuestions: z
    .array(
      z.object({
        key: z.string().trim().min(1),
        en: z.string().trim().min(1),
        zh: z.string().trim().min(1),
      }),
    )
    .max(8)
    .optional(),
  installationCountry: z
    .string()
    .trim()
    .min(2, "Enter the installation country. / 请输入安装国家。"),
  targetDate: z.string().trim().optional(),
  projectStage: z
    .enum(["concept", "design", "tender", "procurement", "replacement"])
    .optional(),
  name: z.string().trim().min(2, "Enter your name. / 请输入姓名。"),
  company: z.string().trim().min(2, "Enter your company. / 请输入公司名称。"),
  businessEmail: z
    .string()
    .trim()
    .email("Enter a valid business email. / 请输入有效的商务邮箱。"),
  phone: z.string().trim().optional(),
  contactCountry: z
    .string()
    .trim()
    .min(2, "Enter your country. / 请输入所在国家。"),
  role: z.string().trim().optional(),
  consent: z
    .boolean()
    .refine(
      (value) => value,
      "Consent is required to process this concept RFQ. / 必须同意后才能处理此概念 RFQ。",
    ),
});

export type RfqValues = z.infer<typeof rfqSchema>;

export const rfqStepFields = [
  ["flow", "head", "frequencyHz", "fluid", "temperature"],
  ["quantity", "installationCountry"],
  ["name", "company", "businessEmail", "contactCountry", "consent"],
] as const satisfies readonly (readonly (keyof RfqValues)[])[];

export interface AttachmentMeta {
  name: string;
  type: string;
  size: number;
}

const allowedAttachmentTypes = new Set([
  "application/pdf",
  "image/jpeg",
  "image/png",
]);
const allowedAttachmentExtensions = new Set([".pdf", ".jpg", ".jpeg", ".png"]);
export const MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024;

export function validateAttachment(file?: AttachmentMeta): string | undefined {
  if (!file || file.size === 0) return undefined;
  const extension = file.name
    .slice(file.name.lastIndexOf("."))
    .toLocaleLowerCase("en-US");
  if (
    !allowedAttachmentTypes.has(file.type) ||
    !allowedAttachmentExtensions.has(extension)
  ) {
    return "Attach one PDF, JPEG, or PNG file. / 请附加一个 PDF、JPEG 或 PNG 文件。";
  }
  if (file.size > MAX_ATTACHMENT_BYTES) {
    return "Attachment must be 10 MB or smaller. / 附件不得超过 10 MB。";
  }
  return undefined;
}

export function buildRfqSummary(values: RfqValues): string {
  const zhValue = (value: string | undefined, fallback: string) =>
    (
      ({
        "Clean water": "清水",
        "Water / glycol — review": "水 / 乙二醇 — 需复核",
        "Other fluid — review": "其他介质 — 需复核",
        "Cast iron concept": "铸铁概念",
        "Stainless steel concept": "不锈钢概念",
        Concept: "概念阶段",
        Design: "设计阶段",
        Tender: "投标阶段",
        Procurement: "采购阶段",
        Replacement: "替换项目",
      }) as Record<string, string>
    )[value || ""] ||
    value ||
    fallback;
  const flowUnit = values.unitSystem === "metric" ? "m³/h" : "US gpm";
  const headUnit = values.unitSystem === "metric" ? "m" : "ft";
  const temperatureUnit = values.unitSystem === "metric" ? "°C" : "°F";
  const selectedModel =
    nxSeries.productModels.find((model) => model.id === values.selectedModelId)
      ?.model ||
    values.selectedModelId ||
    "Engineering review requested";
  return [
    "ASTERFLOW NX — TECHNICAL RFQ CONCEPT SUMMARY",
    "ASTERFLOW NX — 技术 RFQ 概念摘要",
    "Illustrative concept data — not for engineering selection.",
    "示意性概念数据——不用于工程选型。",
    "",
    `Model: ${selectedModel}`,
    `型号：${selectedModel === "Engineering review requested" ? "请求工程复核" : selectedModel}`,
    `Duty: ${values.flow} ${flowUnit} at ${values.head} ${headUnit}`,
    `工况：${values.flow} ${flowUnit}，扬程 ${values.head} ${headUnit}`,
    `Frequency: ${values.frequencyHz} Hz`,
    `频率：${values.frequencyHz} Hz`,
    `Fluid / temperature: ${values.fluid} / ${values.temperature} ${temperatureUnit}`,
    `介质 / 温度：${zhValue(values.fluid, "未提供")} / ${values.temperature} ${temperatureUnit}`,
    `NPSHa / suction: ${values.npsha ?? "Not provided"} / ${values.suctionCondition || "Not provided"}`,
    `NPSHa / 吸入条件：${values.npsha ?? "未提供"} / ${values.suctionCondition || "未提供"}`,
    `Material / seal: ${values.materialPreference || "Review required"} / ${values.sealPreference || "Review required"}`,
    `材料 / 密封：${zhValue(values.materialPreference, "需要复核")} / ${zhValue(values.sealPreference, "需要复核")}`,
    `Motor: ${values.voltageV ? `${values.voltageV} V` : "Review required"}${values.phase ? `, ${values.phase}-phase` : ""}${values.vfdRequired ? ", VFD required" : ""}`,
    `电机：${values.voltageV ? `${values.voltageV} V` : "需要复核"}${values.phase ? `，${values.phase} 相` : ""}${values.vfdRequired ? "，需要变频器" : ""}`,
    `Quantity / installation: ${values.quantity} / ${values.installationCountry}`,
    `数量 / 安装国家：${values.quantity} / ${values.installationCountry}`,
    `Standards requested: ${values.requiredStandards || "None specified"}`,
    `要求标准：${values.requiredStandards || "未指定"}`,
    ...(values.reviewQuestions?.length
      ? [
          "Open review questions:",
          ...values.reviewQuestions.map((question) => `- ${question.en}`),
          "待复核问题：",
          ...values.reviewQuestions.map((question) => `- ${question.zh}`),
        ]
      : []),
    `Project stage: ${values.projectStage || "Not provided"}`,
    `项目阶段：${zhValue(values.projectStage, "未提供")}`,
    "",
    "Status: Received by the local demo route; no email, CRM, or quotation system is connected.",
    "状态：本地演示接口已接收；未连接邮件、CRM 或报价系统。",
    "Final selection, NPSH margin, materials, motor, compliance, and performance require manufacturer review.",
    "最终选型、NPSH 裕量、材料、电机、合规性与性能均须制造商复核。",
  ].join("\n");
}
