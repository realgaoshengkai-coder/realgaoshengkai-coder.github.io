import {
  Children,
  cloneElement,
  isValidElement,
  type ReactElement,
  type ReactNode,
} from "react";

export function Bi({
  en,
  zh,
  className = "",
}: {
  en: ReactNode;
  zh: ReactNode;
  className?: string;
}) {
  return (
    <span className={`bi-copy ${className}`.trim()}>
      <span lang="en">{en}</span>
      <span lang="zh-CN">{zh}</span>
    </span>
  );
}

const zh: Record<string, string> = {
  "Skip to product content": "跳至产品内容",
  "AsterFlow NX home": "AsterFlow NX 首页",
  "Product navigation": "产品导航",
  Product: "产品",
  Duty: "工况",
  Curve: "曲线",
  RFQ: "技术询价",
  Applications: "应用",
  Select: "选型",
  Performance: "性能",
  Documents: "文档",
  "Request technical quote": "提交技术询价",
  "Horizontal single-stage end-suction pump": "卧式单级端吸离心泵",
  "Match the duty.": "匹配工况。",
  "Then discuss the pump.": "再讨论泵。",
  "A clearer decision path for HVAC and industrial cooling: preliminary shortlist, inspect the curve, then send the same technical context to application engineering.":
    "面向 HVAC 与工业冷却的清晰决策路径：先做初步候选，再查看曲线，最后把同一套技术信息交给应用工程师复核。",
  "Select by duty point": "按工况点初选",
  "Download SAMPLE overview": "下载 SAMPLE 系列概览",
  Arrangement: "结构形式",
  "End-suction / back-pull-out concept": "端吸 / 后拉式概念结构",
  Application: "应用",
  "HVAC / clean-water cooling": "HVAC / 清水冷却循环",
  "Frequency coverage": "频率覆盖",
  "50 Hz curves · 60 Hz review": "50 Hz 曲线 · 60 Hz 工程复核",
  "PORTFOLIO CONCEPT": "作品集概念",
  "Fictional brand & dataset": "虚构品牌与数据集",
  "Illustrative concept data — not for engineering selection.":
    "示意性概念数据——不用于工程选型。",
  "Final duty, curve, NPSH margin, materials and compliance require manufacturer review.":
    "最终工况、曲线、NPSH 裕量、材料与合规性均须制造商复核。",
  "Application fit": "适用范围",
  "Start with the service boundary.": "先明确使用边界。",
  "This concept narrows the decision to clean-water circulation. Conditions outside that envelope move to engineering review instead of receiving a guessed match.":
    "本概念仅覆盖清水循环。超出该边界的工况将进入工程复核，而不会得到猜测式匹配。",
  "HVAC circulation": "HVAC 循环",
  "Chilled-water and condenser-water loops with clean-water-like fluids.":
    "适用于冷冻水与冷却水等近似清水介质循环。",
  "District energy": "区域能源",
  "Closed-loop circulation where duty point and installation data are known.":
    "适用于工况点与安装条件明确的闭式循环。",
  "Industrial cooling": "工业冷却",
  "General clean-water heat-rejection and process-cooling loops.":
    "适用于常规清水散热与工艺冷却循环。",
  "Engineering review required:": "以下工况须工程复核：",
  "fire protection · potable-water certification · explosive atmosphere · abrasive solids · aggressive chemicals":
    "消防 · 饮用水认证 · 爆炸性环境 · 磨蚀性固体 · 强腐蚀性化学介质",
  "Case evidence": "案例证据",
  "See how the decision interface was built.": "查看这套决策界面如何构建。",
  "Seven cards connect the commercial problem, engineering truth, interaction decisions and verified prototype states.":
    "七张证据卡串联商业问题、工程事实、交互决策与已验证的原型状态。",
  "Open the seven-card case evidence flow →": "打开七卡案例证据流 →",
  "Fictional portfolio concept · 2026": "虚构作品集概念 · 2026",
  "This unsolicited concept is not an official project for CNP or any reference manufacturer. It does not constitute engineering selection, procurement advice or a performance guarantee.":
    "本自主概念并非南方泵业或任何参考制造商的官方项目，不构成工程选型、采购建议或性能保证。",
  "Simplified end-suction pump concept": "简化端吸离心泵概念",
  "An original line drawing showing an axial inlet, volute casing, shaft, coupling and motor.":
    "原创线稿展示轴向入口、蜗壳、泵轴、联轴器与电机。",
  "AXIAL SUCTION": "轴向吸入口",
  "RADIAL DISCHARGE": "径向排出口",
  MOTOR: "电机",
  "CONCEPT ASSEMBLY · NOT TO SCALE": "概念总成 · 非比例图",

  "01 / Quick selector": "01 / 快速初选",
  "Start from the system duty.": "从系统工况开始。",
  "Enter the required operating point. The selector interpolates the local 50 Hz concept curves and explains every shortlist score.":
    "输入所需运行点。初选器对本地 50 Hz 概念曲线进行插值，并解释每一项候选评分。",
  "Display units": "显示单位",
  Metric: "公制",
  US: "美制",
  "Required flow": "所需流量",
  "Required head": "所需扬程",
  Frequency: "频率",
  "50 Hz — curve data available": "50 Hz — 已有曲线数据",
  "60 Hz — Engineering review": "60 Hz — 工程复核",
  "Fluid temperature": "介质温度",
  "Advanced conditions": "高级工况",
  "These values are carried into the RFQ for review; they do not silently alter the illustrative curve.":
    "这些参数会带入 RFQ 供复核，不会暗中改变示意曲线。",
  Fluid: "介质",
  "Clean water": "清水",
  "Water / glycol — review": "水 / 乙二醇 — 需复核",
  "Other fluid — review": "其他介质 — 需复核",
  "Specific gravity": "比重",
  "NPSHa (": "可用汽蚀余量 NPSHa（",
  NPSHa: "可用汽蚀余量 NPSHa",
  "Viscosity (cSt)": "黏度（cSt）",
  "Material preference": "材料偏好",
  "Engineering review": "工程复核",
  "Cast iron concept": "铸铁概念",
  "Stainless steel concept": "不锈钢概念",
  "VFD required": "需要变频器",
  "Boundary:": "边界：",
  "preliminary shortlist only. Final selection and NPSH margin require manufacturer review.":
    "仅提供初步候选。最终选型与 NPSH 裕量须制造商复核。",
  "Show preliminary shortlist": "显示初步候选",
  "02 / Preliminary shortlist": "02 / 初步候选",
  "This duty needs Engineering review.": "该工况需要工程复核。",
  "Models are first filtered by curve coverage, temperature and available head. Only eligible models receive the transparent v1 score.":
    "型号先按曲线覆盖、温度与可用扬程过滤，只有合格型号才进入透明的 v1 评分。",
  "Best illustrative match": "最佳示意匹配",
  "Within illustrative POR": "位于示意 POR 内",
  "Near illustrative POR": "接近示意 POR 边界",
  "Available head": "可用扬程",
  "Duty efficiency": "工况效率",
  "BEP flow": "BEP 流量",
  "/ 100 illustrative match score": "/ 100 示意匹配分",
  "illustrative match score": "示意匹配分",
  "Head margin": "扬程裕量",
  "BEP proximity": "BEP 接近度",
  Efficiency: "效率",
  "View curve": "查看曲线",
  "Add to RFQ": "加入 RFQ",
  "Why other models were excluded": "其他型号为何被排除",
  "MISSING FREQUENCY DATA": "缺少频率数据",
  "NO ELIGIBLE CONCEPT CURVE": "无合格概念曲线",
  "No synthetic match was generated.": "未生成任何模拟匹配。",
  "Continue to Technical RFQ": "继续填写技术 RFQ",
  "Verify final duty and manufacturer curve.": "请核实最终工况与制造商曲线。",
  "Duty is outside the illustrative POR.": "工况位于示意 POR 之外。",
  "Application engineering review is required.": "需要应用工程复核。",
  "The concept dataset contains 50 Hz curves only.":
    "概念数据集仅包含 50 Hz 曲线。",
  "A 60 Hz curve must be supplied and reviewed by application engineering.":
    "必须提供 60 Hz 曲线并由应用工程师复核。",
  "Flow is outside every illustrative curve.": "流量超出全部示意曲线范围。",
  "No 50 Hz concept curve provides the requested head at this flow.":
    "在该流量下，没有 50 Hz 概念曲线能够提供所需扬程。",
  "Send the duty point for application engineering review.":
    "请提交工况点供应用工程复核。",
  "insufficient head": "扬程不足",
  "temperature out of range": "温度超出范围",
  "curve out of range": "曲线范围外",

  "03 / Interactive performance": "03 / 交互性能",
  "Q–H, BEP and POR all come from the same typed concept record. Change units or choose another shortlist card to update this view.":
    "Q–H、BEP 与 POR 均来自同一条类型化概念记录。切换单位或选择其他候选即可更新此视图。",
  "Q–H curve": "Q–H 曲线",
  Requested: "需求点",
  "Curve head": "曲线扬程",
  "Illustrative POR": "示意 POR",
  "ILLUSTRATIVE POR": "示意 POR",
  DUTY: "工况点",
  BEP: "最佳效率点",
  NPSHr: "必需汽蚀余量 NPSHr",
  "Interpolated efficiency": "插值效率",
  "Interpolated NPSHr": "插值 NPSHr",
  "Shaft power": "轴功率",
  "Flow vs BEP": "流量与 BEP 对比",
  "% away": "% 偏离",
  "NPSHr is a pump characteristic. Confirm NPSHa, margin and suction conditions with application engineering.":
    "NPSHr 是泵的特性参数。请与应用工程师确认 NPSHa、裕量及吸入条件。",
  "Open accessible curve data table": "展开无障碍曲线数据表",
  "Efficiency (%)": "效率（%）",
  "Flow (": "流量（",
  "Head (": "扬程（",
  "NPSHr (": "NPSHr（",
  "Shaft power (": "轴功率（",

  "Construction & service": "结构与维护",
  "Maintenance intent, not decorative anatomy.":
    "表达维护意图，而非装饰性剖视。",
  "The diagram communicates the back-pull-out service sequence without pretending to be a verified sectional drawing or installation dimension.":
    "该图用于说明后拉式维护顺序，不冒充已验证的剖面图或安装尺寸。",
  "Back-pull-out pump service concept": "后拉式泵维护概念",
  "A simplified original diagram labels the volute, impeller, shaft seal, bearing bracket, coupling and motor, with the rotating assembly moving away from connected piping for service.":
    "简化原创图标注蜗壳、叶轮、轴封、轴承架、联轴器与电机，并展示转子总成脱离已连接管路进行维护。",
  "VOLUTE CASING": "蜗壳",
  IMPELLER: "叶轮",
  "BEARING BRACKET": "轴承架",
  COUPLING: "联轴器",
  "BACK-PULL-OUT SERVICE DIRECTION": "后拉式维护方向",
  "Original simplified concept diagram · not to scale · final service clearance must be confirmed from manufacturer drawings.":
    "原创简化概念图 · 非比例图 · 最终维护空间须以制造商图纸确认。",
  "Configuration matrix": "配置矩阵",
  "Expose the decisions that change the quotation.": "明确会改变报价的决策项。",
  "Availability is deliberately left for manufacturer confirmation. The interface collects configuration intent instead of manufacturing options it cannot prove.":
    "可供性明确留待制造商确认。界面只收集配置意图，不虚构无法证明的制造选项。",
  Decision: "决策项",
  "Concept options": "概念选项",
  Status: "状态",
  "Supply scope": "供货范围",
  "Bare pump · base-mounted pump and motor set": "裸泵 · 底座式泵与电机成套",
  Confirm: "待确认",
  "Wetted material": "过流材料",
  "Cast iron concept · stainless steel concept": "铸铁概念 · 不锈钢概念",
  "Fluid review": "介质复核",
  "Shaft seal": "轴封",
  "Mechanical seal preference captured in RFQ": "RFQ 中收集机械密封偏好",
  "Seal review": "密封复核",
  Motor: "电机",
  "Regional voltage / phase · VFD intent": "区域电压 / 相数 · 变频需求",
  "Electrical review": "电气复核",
  "Standards & evidence": "标准与证据",
  "Every badge needs a truth status.": "每一个标识都需要真实状态。",
  "Reference explains design intent. It does not create a certificate, test report or market approval.":
    "参考资料用于说明设计意图，并不产生证书、测试报告或市场准入。",
  "Dimensional and designation reference for this prototype.":
    "本原型的尺寸与命名参考。",
  "Reference verified": "参考已核验",
  "Class II technical reference; no conformity claim is made.":
    "Class II 技术参考；不作符合性声明。",
  "ISO 9906 report": "ISO 9906 报告",
  "A real quotation would identify the agreed test grade and report.":
    "真实报价应明确约定的测试等级与报告。",
  "Not supplied": "未提供",
  "Performance curves": "性能曲线",
  "Synthetic values built only to test the information experience.":
    "合成数值仅用于测试信息体验。",
  Illustrative: "示意性",
  "Document library": "文档库",
  "Make proof status visible before download.": "下载前先看清证据状态。",
  "These files are watermarked SAMPLE artifacts. CAD, BIM, certificates and manufacturer test reports remain unavailable in this concept.":
    "这些文件均带有 SAMPLE 水印。本概念不提供 CAD、BIM、证书或制造商测试报告。",
  "NX Series overview": "NX 系列概览",
  "SAMPLE PDF · portfolio concept": "SAMPLE PDF · 作品集概念",
  Download: "下载",
  "NX 65-40-200 datasheet": "NX 65-40-200 数据表",
  "SAMPLE PDF · 50 Hz illustrative values": "SAMPLE PDF · 50 Hz 示意数值",
  "Installation data request": "安装数据需求表",
  "SAMPLE PDF · information checklist": "SAMPLE PDF · 信息清单",
  "SAMPLE / CONCEPT only · not approved for procurement, installation or construction.":
    "仅供 SAMPLE / 概念展示 · 未批准用于采购、安装或施工。",

  "04 / Technical RFQ": "04 / 技术 RFQ",
  "Send the decision context, not “Contact us”.":
    "传递决策信息，而不是一句“联系我们”。",
  "Three short steps inherit the duty and selected model. The local demo route validates the same schema and stores nothing.":
    "三个简短步骤会继承工况与所选型号。本地演示接口使用同一验证规则，且不保存数据。",
  "RFQ progress": "RFQ 进度",
  "Selected duty": "已选工况",
  "System & configuration": "系统与配置",
  Contact: "联系信息",
  "Step 1 — Selected duty": "步骤 1 — 已选工况",
  "Model can remain blank when the selector returns Engineering review.":
    "当初选结果为工程复核时，型号可以留空。",
  "Selected concept model": "所选概念型号",
  "Engineering review requested": "请求工程复核",
  Flow: "流量",
  Head: "扬程",
  "60 Hz — review": "60 Hz — 复核",
  "Step 2 — System and configuration": "步骤 2 — 系统与配置",
  "Quantity and installation country are required. Unknown engineering conditions can remain blank for review.":
    "数量与安装国家为必填项。未知工程条件可留空待复核。",
  "Suction condition": "吸入条件",
  "Tank level, lift, pressure…": "液位、吸上高度、压力…",
  "Solids (%)": "固体含量（%）",
  "Seal preference": "密封偏好",
  "Voltage (V)": "电压（V）",
  Phase: "相数",
  Review: "复核",
  "1 phase": "单相",
  "3 phase": "三相",
  "Motor enclosure": "电机防护形式",
  "e.g. TEFC requirement": "例如：TEFC 要求",
  "Quantity *": "数量 *",
  "Installation country *": "安装国家 *",
  "Target date": "目标日期",
  "Required standards": "要求标准",
  "List project or market requirements": "列出项目或市场要求",
  "Attach one technical file (PDF, JPEG or PNG · max 10 MB)":
    "附加 1 个技术文件（PDF、JPEG 或 PNG · 最大 10 MB）",
  "Step 3 — Contact and project stage": "步骤 3 — 联系信息与项目阶段",
  "This prototype uses the details only to validate the local form. Nothing is persisted or sent.":
    "本原型仅使用这些信息验证本地表单，不保存也不发送。",
  "Name *": "姓名 *",
  "Company *": "公司 *",
  "Business email *": "商务邮箱 *",
  "Phone / WhatsApp": "电话 / WhatsApp",
  "Country *": "国家 *",
  Role: "角色",
  "Project stage": "项目阶段",
  "Select if known": "如已知请选择",
  Concept: "概念阶段",
  Design: "设计阶段",
  Tender: "投标阶段",
  Procurement: "采购阶段",
  Replacement: "替换项目",
  "I consent to this local prototype processing the entered data to generate a technical summary.":
    "我同意本地原型处理所填数据，以生成技术摘要。",
  Back: "返回",
  Continue: "继续",
  "Validating…": "验证中…",
  "Generate technical summary": "生成技术摘要",
  "Prototype boundary": "原型边界",
  "No email or CRM connection": "未连接邮件或 CRM",
  "No contact data persistence": "不保存联系人数据",
  "Attachment bytes are discarded": "附件字节会被丢弃",
  "No quote, lead time or engineering approval": "不提供报价、交期或工程批准",
  "Local demo submission accepted": "本地演示已接收",
  "The technical context stayed intact.": "技术上下文已完整保留。",
  "No email, CRM or quotation backend is connected. Use this deterministic summary as the handoff artifact.":
    "未连接邮件、CRM 或报价后台。请将这份确定性摘要作为交接材料。",
  Copied: "已复制",
  "Copy summary": "复制摘要",
  "Download .txt": "下载 .txt",

  "ASTERFLOW NX / CASE EVIDENCE": "ASTERFLOW NX / 案例证据",
  "← Back to interactive product page": "← 返回交互产品页",
  "Seven cards · export size 1080 × 1440": "七张卡片 · 导出尺寸 1080 × 1440",
  "BUSINESS HOOK": "商业切口",
  "The page was full of specifications.": "页面堆满了参数。",
  "But the buyer still had to": "但买家仍然需要",
  "reconstruct the decision.": "重新拼出决策逻辑。",
  "PUBLIC BENCHMARK PATTERN": "公开基准页面模式",
  "Series introduction": "系列介绍",
  "Generic inquiry": "通用询盘",
  "REBUILT DECISION PATH": "重构后的决策路径",
  "Duty input": "工况输入",
  "Preliminary shortlist": "初步候选",
  "Curve + evidence": "曲线 + 证据",
  "Technical RFQ": "技术 RFQ",
  "Context-preserving handoff": "保留上下文的交接",
  "Benchmark: CNP NISO / NIS / NISF public product page, accessed 2026-07-29. Structural audit only; no brand assets or copy reproduced.":
    "基准：CNP NISO / NIS / NISF 公开产品页，访问于 2026-07-29。仅作结构审视，未复制品牌资产或文案。",
  "Problem reframed: catalogue page → purchase-decision interface":
    "问题重构：目录页 → 采购决策界面",
  "BUYER QUESTIONS": "买家问题",
  "The information architecture starts here.": "信息架构从这里开始。",
  "Seven questions an overseas technical buyer needs answered.":
    "海外技术买家需要得到回答的七个问题。",
  "Can this product family serve my clean-water duty?":
    "该产品系列能否满足我的清水工况？",
  "Which curve covers my required flow and head?":
    "哪条曲线覆盖我所需的流量与扬程？",
  "How far is the point from BEP and the stated POR?":
    "该工况点距离 BEP 与标示 POR 有多远？",
  "What are efficiency, NPSHr and shaft power at that point?":
    "该点的效率、NPSHr 与轴功率是多少？",
  "Which material, seal and motor conditions still need review?":
    "哪些材料、密封与电机条件仍需复核？",
  "Which documents are evidence and which are only SAMPLE?":
    "哪些文档是证据，哪些仅为 SAMPLE？",
  "Can the selected context travel into the RFQ without retyping?":
    "已选上下文能否无需重复输入直接进入 RFQ？",
  "UX decision": "UX 决策",
  "Organize the page by decisions, not by the order in which an engineering brochure happens to describe the product.":
    "页面应按决策组织，而不是照搬工程样本描述产品的顺序。",
  "Primary user: mechanical / HVAC engineer or technical buyer":
    "主要用户：机械 / HVAC 工程师或技术采购",
  "TRUTH CONTRACT": "真实性契约",
  "Evidence before interface.": "先有证据，再做界面。",
  "What the prototype knows—and where it must stop.":
    "原型知道什么，以及必须在哪里停止。",
  KNOWN: "已知",
  "50 Hz concept dataset": "50 Hz 概念数据集",
  "Three typed model curves with Q–H, efficiency, NPSHr and power.":
    "三条类型化型号曲线，包含 Q–H、效率、NPSHr 与功率。",
  REFERENCE: "参考",
  "ISO / HI definitions": "ISO / HI 定义",
  "Design language and operating-region meaning—not certification.":
    "用于设计语言与运行区间解释——并非认证。",
  REVIEW: "复核",
  "60 Hz performance": "60 Hz 性能",
  "No curve supplied. The UI returns Engineering review.":
    "未提供曲线，界面返回工程复核。",
  "NOT CLAIMED": "未声称",
  "Approval or outcome": "批准或结果",
  "No real selection, certificate, sales uplift, price or lead time.":
    "不声称真实选型、证书、销售提升、价格或交期。",
  "FAIL-CLOSED RULE": "失效关闭规则",
  "Missing evidence changes the UI state—not just a footnote.":
    "缺失证据会改变界面状态，而不只是增加脚注。",
  "Illustrative concept data — not for engineering selection":
    "示意性概念数据——不用于工程选型",
  "SELECTION LOGIC": "选型逻辑",
  "Golden trace · 40 m³/h · 45 m · 50 Hz · 20 °C":
    "黄金路径 · 40 m³/h · 45 m · 50 Hz · 20 °C",
  "The shortlist shows the reason, not just the answer.":
    "候选结果展示原因，而不只是答案。",
  INPUT: "输入",
  FILTER: "过滤",
  RESULT: "结果",
  "curves eligible": "条曲线合格",
  "best concept match": "最佳概念匹配",
  "Target is 10% illustrative margin": "目标为 10% 示意裕量",
  "40 m³/h equals concept BEP": "40 m³/h 等于概念 BEP",
  "77% interpolated at duty": "工况点插值效率 77%",
  Total: "总分",
  "Illustrative match score, not confidence": "示意匹配分，并非置信度",
  "NX 50-32-160 excluded:": "NX 50-32-160 被排除：",
  "interpolated head is below the required 45 m. Filtering happens before scoring.":
    "插值扬程低于所需 45 m。先过滤，后评分。",
  "Policy v1 is deterministic, versioned and independently tested":
    "Policy v1 具有确定性、版本化并经过独立测试",
  "PERFORMANCE VIEW": "性能视图",
  "One selected model · one shared data record.":
    "一个所选型号 · 一条共享数据记录。",
  "Turn the curve into a decision checkpoint.": "把曲线变成决策检查点。",
  "The visual is paired with an expandable data table. Units convert values and axes, not labels alone.":
    "图形配有可展开数据表。单位切换会转换数值与坐标轴，而不只是标签。",
  "POR is model-specific and explicitly illustrative":
    "POR 按型号定义，并明确标示为示意",
  "TECHNICAL RFQ": "技术 RFQ",
  "The selection should survive the handoff.": "选型上下文应在交接中保留。",
  "Replace a generic contact form with a review-ready technical brief.":
    "用可供复核的技术简报替代通用联系表单。",
  "Model · flow · head · frequency · fluid · temperature":
    "型号 · 流量 · 扬程 · 频率 · 介质 · 温度",
  "NPSHa · suction · material · seal · motor · standards · file":
    "NPSHa · 吸入 · 材料 · 密封 · 电机 · 标准 · 文件",
  "Contact & stage": "联系信息与阶段",
  "Company context and explicit local-demo consent":
    "公司背景与明确的本地演示同意",
  "DETERMINISTIC HANDOFF": "确定性交接",
  "Output: copyable and downloadable technical summary":
    "输出：可复制、可下载的技术摘要",
  "No CRM or email integration": "未集成 CRM 或邮件",
  "No contact or attachment persistence": "不保存联系人或附件",
  "PROOF & POSITIONING": "证明与定位",
  "Not a visual redesign exercise.": "这不是一次视觉改版练习。",
  "A working proof that engineering detail can become buyer decision information.":
    "一份可运行的证明：工程细节可以转化为买家决策信息。",
  "deterministic shortlist": "确定性候选",
  "fail-closed review": "失效关闭复核",
  "context-preserving RFQ": "保留上下文的 RFQ",
  "serious / critical axe issues": "个 serious / critical axe 问题",
  POSITIONING: "定位",
  "I restructure overseas product pages for Chinese electromechanical manufacturers—so complex parameters become information buyers can understand, shortlist and carry into a technical inquiry.":
    "我为中国机电制造商重构海外产品页，让复杂参数变成买家看得懂、能初选并可直接带入技术询价的信息。",
  "Open interactive product page": "打开交互产品页",
  "No real engineering selection or inquiry-growth claim is made.":
    "不声称真实工程选型结果或询盘增长。",
  "Duty and preliminary shortlist": "工况与初步候选",
  "Performance and evidence": "性能与证据",
  "Technical RFQ and case evidence": "技术 RFQ 与案例证据",
  "Enter one duty point to reveal the shortlist.":
    "输入一个工况点即可查看候选。",
  "The center product remains fixed while the decision evidence changes around it.":
    "中心产品保持固定，周围的决策证据随页面变化。",
  "The curve waits for a valid 50 Hz shortlist.":
    "曲线将在获得有效的 50 Hz 候选后显示。",
  "A 60 Hz request stays in Engineering review and never receives a synthetic curve.":
    "60 Hz 请求始终进入工程复核，不会生成合成曲线。",
  "Seven cards prove how the decision interface was built.":
    "七张卡片证明这套决策界面如何构建。",
  "Business problem, buyer questions, truth contract, selection policy, curve reading, RFQ handoff and positioning remain available as one evidence stream.":
    "商业问题、买家问题、真实性契约、选型策略、曲线阅读、RFQ 交接与定位被保留为一条完整证据流。",
  "Open seven-card evidence": "打开七卡证据流",
  "illustrative dataset": "示意数据集",
  "real selection claims": "真实选型声明",
  "3 steps": "3 个步骤",
  "Product evidence": "产品证据",
  "Keep proof status beside the product.": "让证据状态始终与产品并列。",
  "The fixed 3D pump explains arrangement. These compact drawers expose the configuration, reference and document boundaries behind it.":
    "固定的 3D 泵用于解释结构；这些紧凑抽屉进一步呈现配置、参考资料与文档边界。",
  "Concept configuration options and evidence status": "概念配置选项与证据状态",
  "NX 65-40-200 illustrative Q–H curve": "NX 65-40-200 示意 Q–H 曲线",
  "A static concept curve marks the 40 cubic metres per hour at 45 metre duty, the best efficiency point and illustrative preferred operating region.":
    "静态概念曲线标示 40 立方米/小时、45 米扬程的工况点、最佳效率点与示意优选运行区。",
  "REQUESTED DUTY": "需求工况",
  FLOW: "流量",
  HEAD: "扬程",
  "Accessible by design": "无障碍设计",
  "STEP 01": "步骤 01",
  "STEP 02": "步骤 02",
  "STEP 03": "步骤 03",
  "Model: NX 65-40-200 Duty: 40 m³/h at 45 m Frequency: 50 Hz Installation: Germany Status: local demo only":
    "型号：NX 65-40-200 工况：40 m³/h、45 m 频率：50 Hz 安装地：德国 状态：仅本地演示",
  "Client + route schema validation": "客户端 + 路由 Schema 验证",
  "AsterFlow NX Series · complete concept evidence flow":
    "AsterFlow NX Series · 完整概念证据流",
};

function dynamicChinese(text: string): string | undefined {
  const matchCount = text.match(/^(\d+) concept curves cover this duty\.$/);
  if (matchCount) return `${matchCount[1]} 条概念曲线覆盖该工况。`;

  const selectedDuty = text.match(/^(.+) at the selected duty\.$/);
  if (selectedDuty) return `${selectedDuty[1]} 在所选工况点的性能。`;

  const requestedDuty = text.match(
    /^Requested duty is (.+) cubic metres per hour at (.+) metres\.$/,
  );
  if (requestedDuty) {
    return `需求工况为 ${requestedDuty[1]} 立方米/小时，扬程 ${requestedDuty[2]} 米。`;
  }

  const chartTitle = text.match(/^(.+) across the (.+) concept curve$/);
  if (chartTitle) {
    const label = chineseFor(chartTitle[1]) ?? chartTitle[1];
    return `${chartTitle[2]} 概念曲线上的${label}`;
  }

  const download = text.match(/^Download (.+)$/);
  if (download) return `下载 ${download[1]}`;

  return undefined;
}

export function chineseFor(text: string): string | undefined {
  return zh[text] ?? dynamicChinese(text);
}

const inlineOnly = new Set(["option", "title", "desc", "text", "tspan"]);
const translatedStringProps = new Set([
  "aria-label",
  "placeholder",
  "title",
  "alt",
]);

function bilingualText(text: string, parentType?: unknown): ReactNode {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (!normalized) return text;
  const translation = chineseFor(normalized);
  if (!translation) return text;
  if (typeof parentType === "string" && inlineOnly.has(parentType)) {
    return `${normalized} / ${translation}`;
  }
  return <Bi en={normalized} zh={translation} />;
}

export function bilingualize(node: ReactNode, parentType?: unknown): ReactNode {
  if (typeof node === "string") return bilingualText(node, parentType);
  if (typeof node === "number" || node == null || typeof node === "boolean") {
    return node;
  }
  if (Array.isArray(node)) {
    return Children.map(node, (child) => bilingualize(child, parentType));
  }
  if (!isValidElement(node)) return node;

  const element = node as ReactElement<Record<string, unknown>>;
  if (element.type === Bi) return element;
  const props = element.props;
  if (props.lang === "en" || props.lang === "zh-CN") return element;
  const nextProps: Record<string, unknown> = {};
  for (const propName of translatedStringProps) {
    const value = props[propName];
    if (typeof value !== "string") continue;
    const translation = chineseFor(value.replace(/\s+/g, " ").trim());
    if (translation) nextProps[propName] = `${value} / ${translation}`;
  }
  const children = props.children as ReactNode;
  if (children === undefined) return cloneElement(element, nextProps);
  return cloneElement(
    element,
    nextProps,
    Children.map(children, (child) => bilingualize(child, element.type)),
  );
}
