"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { Bi } from "@/features/Bilingual";
import {
  type EvidenceSkin,
  useDecisionScene,
} from "@/features/nx-series/DecisionSceneContext";

type PumpControls = {
  left: () => void;
  right: () => void;
  reset: () => void;
  setAutoRotate: (active: boolean) => void;
};

type PumpMaterials = {
  teal: THREE.MeshStandardMaterial;
  dark: THREE.MeshStandardMaterial;
  metal: THREE.MeshStandardMaterial;
  accent: THREE.MeshStandardMaterial;
};

type SceneBinding = {
  materials: PumpMaterials;
  render: () => void;
};

function cylinder(
  radius: number,
  length: number,
  material: THREE.Material,
  x: number,
  y: number,
  z = 0,
) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius, length, 48),
    material,
  );
  mesh.rotation.z = Math.PI / 2;
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

function buildPump() {
  const teal = new THREE.MeshStandardMaterial({
    color: 0x2aa997,
    metalness: 0.48,
    roughness: 0.32,
  });
  const dark = new THREE.MeshStandardMaterial({
    color: 0x10262d,
    metalness: 0.62,
    roughness: 0.28,
  });
  const metal = new THREE.MeshStandardMaterial({
    color: 0xb8c7c9,
    metalness: 0.82,
    roughness: 0.2,
  });
  const accent = new THREE.MeshStandardMaterial({
    color: 0xd9ff59,
    emissive: 0x27320c,
    metalness: 0.18,
    roughness: 0.3,
  });
  const pump = new THREE.Group();
  pump.rotation.y = -0.42;
  pump.rotation.x = 0.08;

  const base = new THREE.Mesh(new THREE.BoxGeometry(6.8, 0.18, 2.2), dark);
  base.position.set(0.65, -1.45, 0);
  base.castShadow = true;
  base.receiveShadow = true;
  pump.add(base);

  for (const x of [-1.45, 2.55]) {
    const foot = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.38, 1.5), dark);
    foot.position.set(x, -1.18, 0);
    foot.castShadow = true;
    pump.add(foot);
  }

  const casing = cylinder(1.22, 0.72, teal, -1.35, 0);
  pump.add(casing);

  const volute = new THREE.Mesh(
    new THREE.TorusGeometry(1.02, 0.34, 24, 88),
    teal,
  );
  volute.rotation.y = Math.PI / 2;
  volute.position.set(-1.22, 0.06, 0);
  volute.scale.set(1, 1.1, 1);
  volute.castShadow = true;
  pump.add(volute);

  const cover = cylinder(0.63, 0.78, dark, -1.72, 0);
  const hub = cylinder(0.28, 0.9, accent, -1.86, 0);
  pump.add(cover, hub);

  const suction = cylinder(0.48, 1.35, teal, -2.65, 0);
  const suctionFlange = cylinder(0.7, 0.2, dark, -3.3, 0);
  pump.add(suction, suctionFlange);

  const discharge = new THREE.Mesh(
    new THREE.CylinderGeometry(0.42, 0.42, 1.35, 48),
    teal,
  );
  discharge.position.set(-1.2, 1.35, 0);
  discharge.castShadow = true;
  const dischargeFlange = new THREE.Mesh(
    new THREE.CylinderGeometry(0.64, 0.64, 0.2, 48),
    dark,
  );
  dischargeFlange.position.set(-1.2, 2.02, 0);
  pump.add(discharge, dischargeFlange);

  const bearing = cylinder(0.68, 1.55, dark, 0.05, 0);
  const shaft = cylinder(0.13, 4.4, metal, 0.65, 0);
  const coupling = cylinder(0.36, 0.62, accent, 1.12, 0);
  pump.add(bearing, shaft, coupling);

  const motorBody = cylinder(0.82, 2.55, dark, 2.72, 0);
  pump.add(motorBody);
  for (let index = 0; index < 9; index += 1) {
    const fin = new THREE.Mesh(
      new THREE.TorusGeometry(0.84, 0.035, 10, 44),
      teal,
    );
    fin.rotation.y = Math.PI / 2;
    fin.position.set(1.68 + index * 0.26, 0, 0);
    pump.add(fin);
  }
  const motorEnd = cylinder(0.7, 0.28, teal, 4.08, 0);
  const fanCover = cylinder(0.78, 0.34, dark, 4.36, 0);
  pump.add(motorEnd, fanCover);

  const terminal = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.45, 0.75), dark);
  terminal.position.set(2.55, 0.92, 0);
  terminal.castShadow = true;
  pump.add(terminal);

  return { pump, materials: { teal, dark, metal, accent } };
}

function applyEvidenceSkin(materials: PumpMaterials, skin: EvidenceSkin) {
  const styles = {
    baseline: {
      teal: [0x2aa997, 1, false],
      dark: [0x10262d, 1, false],
      metal: [0xb8c7c9, 1, false],
      accent: [0xd9ff59, 1, false],
    },
    illustrative: {
      teal: [0x47baaa, 1, false],
      dark: [0x183d45, 1, false],
      metal: [0xb8c7c9, 1, false],
      accent: [0xd9ff59, 1, false],
    },
    review: {
      teal: [0xe18a55, 1, true],
      dark: [0x73503c, 1, true],
      metal: [0xd9ad86, 1, true],
      accent: [0xffb46a, 1, false],
    },
    uncovered: {
      teal: [0x9d796b, 1, true],
      dark: [0x5c463f, 1, true],
      metal: [0xb59a8f, 1, true],
      accent: [0xf18c69, 1, true],
    },
  } as const;
  const next = styles[skin];

  for (const [name, material] of Object.entries(materials) as [
    keyof PumpMaterials,
    THREE.MeshStandardMaterial,
  ][]) {
    const [color, opacity, wireframe] = next[name];
    material.color.setHex(color);
    material.opacity = opacity;
    material.transparent = opacity < 1;
    material.wireframe = wireframe;
    material.needsUpdate = true;
  }
  materials.accent.emissive.setHex(
    skin === "review" || skin === "uncovered" ? 0x5b1c0b : 0x27320c,
  );
}

export default function PumpScene() {
  const mountRef = useRef<HTMLDivElement>(null);
  const controlsRef = useRef<PumpControls | null>(null);
  const sceneBindingRef = useRef<SceneBinding | null>(null);
  const evidenceSkinRef = useRef<EvidenceSkin>("baseline");
  const [autoRotate, setAutoRotate] = useState(false);
  const { evidenceSkin, focus, counterfactual, reviewQuestions } =
    useDecisionScene();
  evidenceSkinRef.current = evidenceSkin;

  useEffect(() => {
    const binding = sceneBindingRef.current;
    if (!binding) return;
    applyEvidenceSkin(binding.materials, evidenceSkin);
    binding.render();
  }, [evidenceSkin]);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x07151a, 0.045);
    const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
    camera.position.set(8.8, 4.8, 9.8);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.setSize(mount.clientWidth, mount.clientHeight, false);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    mount.appendChild(renderer.domElement);

    const ambient = new THREE.HemisphereLight(0xdafcf7, 0x10262d, 2.1);
    const key = new THREE.DirectionalLight(0xffffff, 4.8);
    key.position.set(4, 8, 5);
    key.castShadow = true;
    const rim = new THREE.PointLight(0xd9ff59, 38, 18);
    rim.position.set(-5, 3, 4);
    scene.add(ambient, key, rim);

    const { pump, materials } = buildPump();
    scene.add(pump);

    const floor = new THREE.Mesh(
      new THREE.CircleGeometry(6.8, 96),
      new THREE.MeshStandardMaterial({
        color: 0x0b1d23,
        metalness: 0.12,
        roughness: 0.78,
        transparent: true,
        opacity: 0.78,
      }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -1.56;
    floor.receiveShadow = true;
    scene.add(floor);

    const grid = new THREE.GridHelper(12, 24, 0x2aa997, 0x21434a);
    grid.position.y = -1.54;
    (grid.material as THREE.Material).transparent = true;
    (grid.material as THREE.Material).opacity = 0.35;
    scene.add(grid);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0.4, 0.15, 0);
    controls.enableDamping = false;
    controls.enablePan = false;
    controls.minDistance = 7;
    controls.maxDistance = 18;
    controls.minPolarAngle = 0.55;
    controls.maxPolarAngle = 1.72;
    controls.autoRotate = false;
    controls.autoRotateSpeed = 0.72;
    controls.saveState();

    let frame = 0;
    const stopAutoRotate = () => {
      controls.autoRotate = false;
      setAutoRotate(false);
      cancelAnimationFrame(frame);
      frame = 0;
    };
    controls.addEventListener("start", stopAutoRotate);

    const render = () => renderer.render(scene, camera);
    const animate = () => {
      if (!controls.autoRotate) {
        frame = 0;
        render();
        return;
      }
      controls.update();
      render();
      frame = requestAnimationFrame(animate);
    };
    controls.addEventListener("change", render);

    controlsRef.current = {
      left: () => {
        controls.rotateLeft(Math.PI / 12);
        controls.update();
      },
      right: () => {
        controls.rotateLeft(-Math.PI / 12);
        controls.update();
      },
      reset: () => controls.reset(),
      setAutoRotate: (active) => {
        controls.autoRotate = active;
        if (active && !frame) animate();
        if (!active && frame) {
          cancelAnimationFrame(frame);
          frame = 0;
          render();
        }
      },
    };

    const resize = () => {
      const width = mount.clientWidth;
      const height = mount.clientHeight;
      if (!width || !height) return;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      render();
    };
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(mount);

    applyEvidenceSkin(materials, evidenceSkinRef.current);
    sceneBindingRef.current = { materials, render };
    render();

    return () => {
      cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      controls.removeEventListener("start", stopAutoRotate);
      controls.removeEventListener("change", render);
      controls.dispose();
      scene.traverse((object) => {
        if (!(object instanceof THREE.Mesh)) return;
        object.geometry.dispose();
        const materials = Array.isArray(object.material)
          ? object.material
          : [object.material];
        for (const material of materials) material.dispose();
      });
      renderer.dispose();
      renderer.domElement.remove();
      sceneBindingRef.current = null;
    };
  }, []);

  function toggleAutoRotate() {
    const next = !autoRotate;
    setAutoRotate(next);
    controlsRef.current?.setAutoRotate(next);
  }

  const skinCopy = {
    baseline: {
      en: "Context layer waiting for a duty input",
      zh: "上下文层等待工况输入",
    },
    illustrative: {
      en: "Illustrative 50 Hz concept layer",
      zh: "示意性 50 Hz 概念层",
    },
    review: {
      en: "Engineering review layer",
      zh: "工程复核层",
    },
    uncovered: {
      en: "Uncovered or withdrawn layer",
      zh: "未覆盖或已撤销层",
    },
  }[evidenceSkin];

  return (
    <aside
      className="pump-stage"
      data-evidence-skin={evidenceSkin}
      data-scene-focus={focus}
      aria-label="Interactive 3D product"
    >
      <div className="pump-stage-copy">
        <span className="series-code">NX 65-40-200 / 50 HZ</span>
        <Bi en="Drag to rotate · scroll to zoom" zh="拖动旋转 · 滚轮缩放" />
      </div>
      <div
        ref={mountRef}
        className="pump-canvas"
        role="img"
        aria-label="Interactive 3D concept model of an end-suction centrifugal pump for clean-water HVAC and industrial cooling circulation / 面向 HVAC 与工业冷却清水循环的端吸离心泵交互式 3D 概念模型"
      />
      <div className="evidence-skin-readout" aria-live="polite">
        <Bi
          className="evidence-state-label"
          en="Evidence state"
          zh="证据状态"
        />
        <strong>{evidenceSkin.toUpperCase()}</strong>
        <Bi en={skinCopy.en} zh={skinCopy.zh} />
        {counterfactual !== "none" && (
          <Bi
            className="counterfactual-readout"
            en="What-if trace active"
            zh="反事实追踪已启用"
          />
        )}
        {reviewQuestions.length > 0 && (
          <Bi
            className="question-readout"
            en={`${reviewQuestions.length} open RFQ question${reviewQuestions.length === 1 ? "" : "s"}`}
            zh={`${reviewQuestions.length} 个待处理 RFQ 问题`}
          />
        )}
      </div>
      <fieldset className="pump-controls">
        <legend className="sr-only">3D model controls / 3D 模型控制</legend>
        <button
          type="button"
          onClick={() => controlsRef.current?.left()}
          aria-label="Rotate left / 向左旋转"
        >
          ←
        </button>
        <button type="button" onClick={toggleAutoRotate}>
          <Bi
            en={autoRotate ? "Pause" : "Auto rotate"}
            zh={autoRotate ? "暂停" : "自动旋转"}
          />
        </button>
        <button type="button" onClick={() => controlsRef.current?.reset()}>
          <Bi en="Reset" zh="复位" />
        </button>
        <button
          type="button"
          onClick={() => controlsRef.current?.right()}
          aria-label="Rotate right / 向右旋转"
        >
          →
        </button>
      </fieldset>
      <div className="pump-stage-boundary">
        <Bi
          en="Procedural 3D concept · not a manufacturing model"
          zh="程序化 3D 概念 · 非制造模型"
        />
      </div>
    </aside>
  );
}
