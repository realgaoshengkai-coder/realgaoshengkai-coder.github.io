import { bilingualize } from "@/features/Bilingual";

const documentCards = [
  {
    name: "NX Series overview",
    meta: "SAMPLE PDF · portfolio concept",
    href: "/samples/AsterFlow_NX_Series_Overview_SAMPLE.pdf",
  },
  {
    name: "NX 65-40-200 datasheet",
    meta: "SAMPLE PDF · 50 Hz illustrative values",
    href: "/samples/AsterFlow_NX_65-40-200_Datasheet_SAMPLE.pdf",
  },
  {
    name: "Installation data request",
    meta: "SAMPLE PDF · information checklist",
    href: "/samples/AsterFlow_NX_Installation_Request_SAMPLE.pdf",
  },
];

export default function StaticSections() {
  return bilingualize(
    <section id="documents" className="evidence-drawer">
      <div className="section-heading">
        <p className="kicker">Product evidence</p>
        <h2>Keep proof status beside the product.</h2>
        <p>
          The fixed 3D pump explains arrangement. These compact drawers expose
          the configuration, reference and document boundaries behind it.
        </p>
      </div>

      <details open>
        <summary>Configuration matrix</summary>
        <section
          className="table-wrap"
          aria-label="Configuration matrix / 配置矩阵"
        >
          <table className="configuration-table">
            <caption>Concept configuration options and evidence status</caption>
            <thead>
              <tr>
                <th scope="col">Decision</th>
                <th scope="col">Concept options</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">Supply scope</th>
                <td>Bare pump · base-mounted pump and motor set</td>
                <td>Confirm</td>
              </tr>
              <tr>
                <th scope="row">Wetted material</th>
                <td>Cast iron concept · stainless steel concept</td>
                <td>Fluid review</td>
              </tr>
              <tr>
                <th scope="row">Shaft seal</th>
                <td>Mechanical seal preference captured in RFQ</td>
                <td>Seal review</td>
              </tr>
              <tr>
                <th scope="row">Motor</th>
                <td>Regional voltage / phase · VFD intent</td>
                <td>Electrical review</td>
              </tr>
            </tbody>
          </table>
        </section>
      </details>

      <details>
        <summary>Standards &amp; evidence</summary>
        <div className="evidence-grid evidence-grid-compact">
          <article>
            <span className="evidence-index">REF 01</span>
            <h3>ISO 2858</h3>
            <p>Dimensional and designation reference for this prototype.</p>
            <span className="status status-reference">Reference verified</span>
          </article>
          <article>
            <span className="evidence-index">REF 02</span>
            <h3>ISO 5199</h3>
            <p>Class II technical reference; no conformity claim is made.</p>
            <span className="status status-reference">Reference verified</span>
          </article>
          <article>
            <span className="evidence-index">TEST 01</span>
            <h3>ISO 9906 report</h3>
            <p>
              A real quotation would identify the agreed test grade and report.
            </p>
            <span className="status status-missing">Not supplied</span>
          </article>
          <article>
            <span className="evidence-index">DATA 01</span>
            <h3>Performance curves</h3>
            <p>
              Synthetic values built only to test the information experience.
            </p>
            <span className="status status-concept">Illustrative</span>
          </article>
        </div>
      </details>

      <details>
        <summary>Document library</summary>
        <p>
          These files are watermarked SAMPLE artifacts. CAD, BIM, certificates
          and manufacturer test reports remain unavailable in this concept.
        </p>
        <div className="document-grid document-grid-compact">
          {documentCards.map((document) => (
            <article className="document-card" key={document.name}>
              <span className="file-mark" aria-hidden="true">
                PDF
              </span>
              <div>
                <h3>{document.name}</h3>
                <p>{document.meta}</p>
              </div>
              <a
                href={document.href}
                download
                aria-label={`Download ${document.name}`}
              >
                Download <span aria-hidden="true">↓</span>
              </a>
            </article>
          ))}
        </div>
        <p className="document-disclaimer">
          SAMPLE / CONCEPT only · not approved for procurement, installation or
          construction.
        </p>
      </details>
    </section>,
  );
}
