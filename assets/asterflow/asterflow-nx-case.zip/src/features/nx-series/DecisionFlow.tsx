"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  type ChangeEvent,
  type FormEvent,
  type ReactNode,
  useEffect,
  useId,
  useState,
} from "react";
import { useForm } from "react-hook-form";
import {
  buildRfqSummary,
  type CurvePoint,
  conversions,
  convertDuty,
  type DisplayDuty,
  fromMetricDuty,
  getPreliminaryShortlist,
  type Match,
  type MetricDuty,
  nxSeries,
  type RfqValues,
  rfqSchema,
  rfqStepFields,
  round,
  toMetricDuty,
  type UnitSystem,
  validateAttachment,
} from "@/domain/pump";
import { Bi, bilingualize } from "@/features/Bilingual";
import { useDecisionScene } from "@/features/nx-series/DecisionSceneContext";
import {
  CounterfactualRail,
  RejectionRail,
  RfqQuestionManifest,
  TenderRedline,
  UnitParityPanel,
} from "@/features/nx-series/DecisionTrace";

const unitLabels = {
  metric: {
    flow: "m³/h",
    head: "m",
    temperature: "°C",
    power: "kW",
    npsh: "m",
  },
  us: {
    flow: "US gpm",
    head: "ft",
    temperature: "°F",
    power: "hp",
    npsh: "ft",
  },
} as const;

interface Conditions {
  fluid: string;
  npsha: string;
  specificGravity: string;
  viscosityCst: string;
  materialPreference: string;
  vfdRequired: boolean;
}

const defaultConditions: Conditions = {
  fluid: "Clean water",
  npsha: "",
  specificGravity: "1",
  viscosityCst: "1",
  materialPreference: "",
  vfdRequired: false,
};

function toDisplayPoint(point: CurvePoint, unitSystem: UnitSystem) {
  return unitSystem === "metric"
    ? {
        flow: point.flowM3h,
        head: point.headM,
        efficiency: point.efficiencyPct,
        npsh: point.npshrM,
        power: point.shaftPowerKw,
      }
    : {
        flow: conversions.m3hToGpm(point.flowM3h),
        head: conversions.mToFt(point.headM),
        efficiency: point.efficiencyPct,
        npsh: conversions.mToFt(point.npshrM),
        power: conversions.kwToHp(point.shaftPowerKw),
      };
}

function UnitToggle({
  unitSystem,
  onChange,
}: {
  unitSystem: UnitSystem;
  onChange: (unit: UnitSystem) => void;
}) {
  return bilingualize(
    <fieldset className="unit-toggle">
      <legend className="sr-only">Display units</legend>
      <button
        type="button"
        aria-pressed={unitSystem === "metric"}
        onClick={() => onChange("metric")}
      >
        Metric
      </button>
      <button
        type="button"
        aria-pressed={unitSystem === "us"}
        onClick={() => onChange("us")}
      >
        US
      </button>
    </fieldset>,
  );
}

function SelectorPanel({
  unitSystem,
  onUnitChange,
  onSubmit,
  conditions,
  onConditionsChange,
}: {
  unitSystem: UnitSystem;
  onUnitChange: (unit: UnitSystem) => void;
  onSubmit: (duty: DisplayDuty) => void;
  conditions: Conditions;
  onConditionsChange: (conditions: Conditions) => void;
}) {
  const [draft, setDraft] = useState({
    flow: "40",
    head: "45",
    temperature: "20",
    frequencyHz: "50",
  });
  const labels = unitLabels[unitSystem];

  function changeUnit(nextUnit: UnitSystem) {
    if (nextUnit === unitSystem) return;
    const converted = convertDuty(
      {
        flow: Number(draft.flow),
        head: Number(draft.head),
        temperature: Number(draft.temperature),
        frequencyHz: Number(draft.frequencyHz) as 50 | 60,
        unitSystem,
      },
      nextUnit,
    );
    setDraft({
      flow: String(converted.flow),
      head: String(converted.head),
      temperature: String(converted.temperature),
      frequencyHz: String(converted.frequencyHz),
    });
    onUnitChange(nextUnit);
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onSubmit({
      flow: Number(draft.flow),
      head: Number(draft.head),
      temperature: Number(draft.temperature),
      frequencyHz: Number(draft.frequencyHz) as 50 | 60,
      unitSystem,
    });
  }

  return bilingualize(
    <section id="selector" className="selector-section">
      <div className="section-shell section-block">
        <div className="section-heading split-heading selector-heading">
          <div>
            <p className="kicker">01 / Quick selector</p>
            <h2>Start from the system duty.</h2>
          </div>
          <div>
            <p>
              Enter the required operating point. The selector interpolates the
              local 50 Hz concept curves and explains every shortlist score.
            </p>
            <UnitToggle unitSystem={unitSystem} onChange={changeUnit} />
          </div>
        </div>

        <form className="selector-panel" onSubmit={submit}>
          <div className="selector-grid">
            <label>
              <span>Required flow</span>
              <span className="input-with-unit">
                <input
                  id="selector-flow"
                  name="flow"
                  type="number"
                  min="0.01"
                  step="any"
                  required
                  value={draft.flow}
                  onChange={(event) =>
                    setDraft({ ...draft, flow: event.target.value })
                  }
                />
                <b>{labels.flow}</b>
              </span>
            </label>
            <label>
              <span>Required head</span>
              <span className="input-with-unit">
                <input
                  id="selector-head"
                  name="head"
                  type="number"
                  min="0.01"
                  step="any"
                  required
                  value={draft.head}
                  onChange={(event) =>
                    setDraft({ ...draft, head: event.target.value })
                  }
                />
                <b>{labels.head}</b>
              </span>
            </label>
            <label>
              <span>Frequency</span>
              <select
                id="selector-frequency"
                name="frequency"
                value={draft.frequencyHz}
                onChange={(event) =>
                  setDraft({ ...draft, frequencyHz: event.target.value })
                }
              >
                <option value="50">50 Hz — curve data available</option>
                <option value="60">60 Hz — Engineering review</option>
              </select>
            </label>
            <label>
              <span>Fluid temperature</span>
              <span className="input-with-unit">
                <input
                  id="selector-temperature"
                  name="temperature"
                  type="number"
                  step="any"
                  required
                  value={draft.temperature}
                  onChange={(event) =>
                    setDraft({ ...draft, temperature: event.target.value })
                  }
                />
                <b>{labels.temperature}</b>
              </span>
            </label>
          </div>

          <details className="advanced-conditions">
            <summary>Advanced conditions</summary>
            <p>
              These values are carried into the RFQ for review; they do not
              silently alter the illustrative curve.
            </p>
            <div className="advanced-grid">
              <label>
                <span>Fluid</span>
                <select
                  value={conditions.fluid}
                  onChange={(event) =>
                    onConditionsChange({
                      ...conditions,
                      fluid: event.target.value,
                    })
                  }
                >
                  <option value="Clean water">Clean water</option>
                  <option value="Water / glycol — review">
                    Water / glycol — review
                  </option>
                  <option value="Other fluid — review">
                    Other fluid — review
                  </option>
                </select>
              </label>
              <label>
                <span>NPSHa ({labels.npsh})</span>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={conditions.npsha}
                  onChange={(event) =>
                    onConditionsChange({
                      ...conditions,
                      npsha: event.target.value,
                    })
                  }
                />
              </label>
              <label>
                <span>Specific gravity</span>
                <input
                  type="number"
                  min="0.01"
                  step="any"
                  value={conditions.specificGravity}
                  onChange={(event) =>
                    onConditionsChange({
                      ...conditions,
                      specificGravity: event.target.value,
                    })
                  }
                />
              </label>
              <label>
                <span>Viscosity (cSt)</span>
                <input
                  type="number"
                  min="0.01"
                  step="any"
                  value={conditions.viscosityCst}
                  onChange={(event) =>
                    onConditionsChange({
                      ...conditions,
                      viscosityCst: event.target.value,
                    })
                  }
                />
              </label>
              <label>
                <span>Material preference</span>
                <select
                  value={conditions.materialPreference}
                  onChange={(event) =>
                    onConditionsChange({
                      ...conditions,
                      materialPreference: event.target.value,
                    })
                  }
                >
                  <option value="">Engineering review</option>
                  <option value="Cast iron concept">Cast iron concept</option>
                  <option value="Stainless steel concept">
                    Stainless steel concept
                  </option>
                </select>
              </label>
              <label className="check-field">
                <input
                  type="checkbox"
                  checked={conditions.vfdRequired}
                  onChange={(event) =>
                    onConditionsChange({
                      ...conditions,
                      vfdRequired: event.target.checked,
                    })
                  }
                />
                <span>VFD required</span>
              </label>
            </div>
          </details>

          <div className="selector-action">
            <p>
              <strong>Boundary:</strong> preliminary shortlist only. Final
              selection and NPSH margin require manufacturer review.
            </p>
            <button className="button button-dark" type="submit">
              Show preliminary shortlist
            </button>
          </div>
        </form>
      </div>
    </section>,
  );
}

function MatchCard({
  match,
  duty,
  unitSystem,
  rank,
  selected,
  onView,
  onAdd,
}: {
  match: Match;
  duty: MetricDuty;
  unitSystem: UnitSystem;
  rank: number;
  selected: boolean;
  onView: () => void;
  onAdd: () => void;
}) {
  const point = toDisplayPoint(match.point, unitSystem);
  const bepFlow =
    unitSystem === "metric"
      ? match.model.operatingRegion.bepFlowM3h
      : conversions.m3hToGpm(match.model.operatingRegion.bepFlowM3h);
  const statusLabel = {
    "within-illustrative-por": "Within illustrative POR",
    "near-illustrative-por-boundary": "Near illustrative POR",
    "engineering-review": "Engineering review",
  }[match.matchState];
  const labels = unitLabels[unitSystem];

  return bilingualize(
    <article className={`match-card${selected ? " selected" : ""}`}>
      <div className="match-card-top">
        <div>
          <span className="rank">0{rank}</span>
          {rank === 1 && (
            <span className="best-match">Best illustrative match</span>
          )}
        </div>
        <span
          className={`status ${
            match.matchState === "within-illustrative-por"
              ? "status-good"
              : "status-review"
          }`}
        >
          {statusLabel}
        </span>
      </div>
      <h3>{match.model.model}</h3>
      <p className="model-meta">
        <Bi
          en={`${match.model.speedRpm} rpm · ${match.model.motorPowerKw} kW motor concept · DN ${match.model.suctionDnMm}/${match.model.dischargeDnMm}`}
          zh={`${match.model.speedRpm} rpm · ${match.model.motorPowerKw} kW 电机概念 · DN ${match.model.suctionDnMm}/${match.model.dischargeDnMm}`}
        />
      </p>
      <dl className="match-metrics">
        <div>
          <dt>Available head</dt>
          <dd>
            {round(point.head)} {labels.head}
          </dd>
        </div>
        <div>
          <dt>Duty efficiency</dt>
          <dd>{round(point.efficiency)}%</dd>
        </div>
        <div>
          <dt>NPSHr</dt>
          <dd>
            {round(point.npsh)} {labels.npsh}
          </dd>
        </div>
        <div>
          <dt>BEP flow</dt>
          <dd>
            {round(bepFlow)} {labels.flow}
          </dd>
        </div>
      </dl>
      <div className="score-panel">
        <div className="score-total">
          <strong>{match.score.total}</strong>
          <span>/ 100 illustrative match score</span>
        </div>
        <div className="score-bar" aria-hidden="true">
          <span style={{ width: `${match.score.total}%` }} />
        </div>
        <dl>
          <div>
            <dt>Head margin</dt>
            <dd>{match.score.headMargin} / 40</dd>
          </div>
          <div>
            <dt>BEP proximity</dt>
            <dd>{match.score.bepProximity} / 35</dd>
          </div>
          <div>
            <dt>Efficiency</dt>
            <dd>{match.score.efficiency} / 25</dd>
          </div>
        </dl>
      </div>
      <p className="match-warning">
        {match.warnings.map((warning) => (
          <span key={warning}>{bilingualize(warning)}</span>
        ))}
      </p>
      <div className="card-actions">
        <button
          className="button button-outline"
          type="button"
          onClick={onView}
        >
          View curve
        </button>
        <button className="button button-dark" type="button" onClick={onAdd}>
          Add to RFQ
        </button>
      </div>
      <span className="sr-only">
        <Bi
          en={`Requested duty is ${round(duty.flowM3h)} cubic metres per hour at ${round(duty.headM)} metres.`}
          zh={`需求工况为 ${round(duty.flowM3h)} 立方米/小时，扬程 ${round(duty.headM)} 米。`}
        />
      </span>
    </article>,
  );
}

function Shortlist({
  outcome,
  unitSystem,
  selectedModelId,
  onSelect,
  conditions,
}: {
  outcome: ReturnType<typeof getPreliminaryShortlist>;
  unitSystem: UnitSystem;
  selectedModelId?: string;
  onSelect: (modelId: string, destination: "performance" | "rfq") => void;
  conditions: Conditions;
}) {
  const { counterfactual } = useDecisionScene();
  return bilingualize(
    <section id="shortlist" className="shortlist-section" aria-live="polite">
      <div className="section-shell section-block">
        <div className="section-heading split-heading">
          <div>
            <p className="kicker">02 / Preliminary shortlist</p>
            <h2>
              {outcome.matches.length > 0
                ? `${outcome.matches.length} concept curves cover this duty.`
                : "This duty needs Engineering review."}
            </h2>
          </div>
          <p>
            Models are first filtered by curve coverage, temperature and
            available head. Only eligible models receive the transparent v1
            score.
          </p>
        </div>

        {outcome.matches.length > 0 ? (
          <>
            <RejectionRail outcome={outcome} />
            <UnitParityPanel
              duty={outcome.dutyMetric}
              unitSystem={unitSystem}
            />
            <TenderRedline
              duty={outcome.dutyMetric}
              outcome={outcome}
              fluid={conditions.fluid}
              materialPreference={conditions.materialPreference}
            />
            <CounterfactualRail />
            {counterfactual === "none" && (
              <>
                <div className="shortlist-grid">
                  {outcome.matches.map((match, index) => (
                    <MatchCard
                      key={match.model.id}
                      match={match}
                      duty={outcome.dutyMetric}
                      unitSystem={unitSystem}
                      rank={index + 1}
                      selected={selectedModelId === match.model.id}
                      onView={() => onSelect(match.model.id, "performance")}
                      onAdd={() => onSelect(match.model.id, "rfq")}
                    />
                  ))}
                </div>
                <details className="excluded-models">
                  <summary>Why other models were excluded</summary>
                  <ul>
                    {outcome.evaluations
                      .filter(
                        (evaluation) => evaluation.eligibility !== "eligible",
                      )
                      .map((evaluation) => {
                        const model = nxSeries.productModels.find(
                          (candidate) => candidate.id === evaluation.modelId,
                        );
                        return (
                          <li key={evaluation.modelId}>
                            <strong>{model?.model}:</strong>{" "}
                            {evaluation.eligibility.replaceAll("-", " ")}
                          </li>
                        );
                      })}
                  </ul>
                </details>
              </>
            )}
          </>
        ) : (
          <div className="engineering-review" role="status">
            <div>
              <span className="review-code">
                {outcome.coverage === "missing-frequency"
                  ? "MISSING FREQUENCY DATA"
                  : "NO ELIGIBLE CONCEPT CURVE"}
              </span>
              <h3>No synthetic match was generated.</h3>
              <ul>
                {outcome.reviewReasons.map((reason) => (
                  <li key={reason}>{reason}</li>
                ))}
              </ul>
            </div>
            <a className="button button-dark" href="#rfq">
              Continue to Technical RFQ
            </a>
          </div>
        )}
      </div>
    </section>,
  );
}

function MiniChart({
  model,
  metric,
  label,
  unit,
  unitSystem,
}: {
  model: Match["model"];
  metric: "efficiencyPct" | "npshrM" | "shaftPowerKw";
  label: string;
  unit: string;
  unitSystem: UnitSystem;
}) {
  const width = 280;
  const height = 112;
  const values = model.curve.map((point) => {
    if (metric === "npshrM") {
      return unitSystem === "metric"
        ? point.npshrM
        : conversions.mToFt(point.npshrM);
    }
    if (metric === "shaftPowerKw") {
      return unitSystem === "metric"
        ? point.shaftPowerKw
        : conversions.kwToHp(point.shaftPowerKw);
    }
    return point.efficiencyPct;
  });
  const max = Math.max(...values) * 1.1;
  const path = values
    .map((value, index) => {
      const x = 12 + (index / (values.length - 1)) * (width - 24);
      const y = height - 14 - (value / max) * (height - 28);
      return `${index === 0 ? "M" : "L"}${x} ${y}`;
    })
    .join(" ");
  return bilingualize(
    <article className="mini-chart">
      <div>
        <span>{label}</span>
        <strong>
          {round(Math.max(...values))} {unit}
        </strong>
      </div>
      <svg viewBox={`0 0 ${width} ${height}`} role="img">
        <title>{`${label} across the ${model.model} concept curve`}</title>
        <path d={`M12 ${height - 14}H${width - 12}`} className="chart-axis" />
        <path d={path} className="mini-line" />
      </svg>
    </article>,
  );
}

function Performance({
  match,
  duty,
  unitSystem,
}: {
  match: Match;
  duty: MetricDuty;
  unitSystem: UnitSystem;
}) {
  const chartId = useId().replaceAll(":", "");
  const labels = unitLabels[unitSystem];
  const displayCurve = match.model.curve.map((point) =>
    toDisplayPoint(point, unitSystem),
  );
  const displayDuty = fromMetricDuty(duty, unitSystem);
  const maxFlow = Math.max(...displayCurve.map((point) => point.flow)) * 1.05;
  const maxHead = Math.max(...displayCurve.map((point) => point.head)) * 1.12;
  const width = 820;
  const height = 420;
  const pad = { left: 70, right: 26, top: 30, bottom: 58 };
  const x = (value: number) =>
    pad.left + (value / maxFlow) * (width - pad.left - pad.right);
  const y = (value: number) =>
    height - pad.bottom - (value / maxHead) * (height - pad.top - pad.bottom);
  const line = displayCurve
    .map(
      (point, index) =>
        `${index === 0 ? "M" : "L"}${x(point.flow)} ${y(point.head)}`,
    )
    .join(" ");
  const porMin =
    unitSystem === "metric"
      ? match.model.operatingRegion.porMinFlowM3h
      : conversions.m3hToGpm(match.model.operatingRegion.porMinFlowM3h);
  const porMax =
    unitSystem === "metric"
      ? match.model.operatingRegion.porMaxFlowM3h
      : conversions.m3hToGpm(match.model.operatingRegion.porMaxFlowM3h);
  const bep = {
    flow:
      unitSystem === "metric"
        ? match.model.operatingRegion.bepFlowM3h
        : conversions.m3hToGpm(match.model.operatingRegion.bepFlowM3h),
    head:
      unitSystem === "metric"
        ? match.model.operatingRegion.bepHeadM
        : conversions.mToFt(match.model.operatingRegion.bepHeadM),
  };
  const selected = toDisplayPoint(match.point, unitSystem);

  return bilingualize(
    <section id="performance" className="performance-section">
      <div className="section-shell section-block">
        <div className="section-heading split-heading">
          <div>
            <p className="kicker">03 / Interactive performance</p>
            <h2>{`${match.model.model} at the selected duty.`}</h2>
          </div>
          <p>
            Q–H, BEP and POR all come from the same typed concept record. Change
            units or choose another shortlist card to update this view.
          </p>
        </div>
        <div className="concept-data-callout">
          <strong>
            Illustrative concept data — not for engineering selection.
          </strong>
          <span>
            <Bi
              en={`50 Hz · ${match.model.speedRpm} rpm · nominal Ø${match.model.nominalImpellerMm} mm`}
              zh={`50 Hz · ${match.model.speedRpm} rpm · 公称叶轮 Ø${match.model.nominalImpellerMm} mm`}
            />
          </span>
        </div>
        <div className="performance-layout">
          <div className="chart-card">
            <div className="chart-header">
              <div>
                <span>Q–H curve</span>
                <strong>{match.model.model}</strong>
              </div>
              <dl>
                <div>
                  <dt>Requested</dt>
                  <dd>
                    {displayDuty.flow} {labels.flow} / {displayDuty.head}{" "}
                    {labels.head}
                  </dd>
                </div>
                <div>
                  <dt>Curve head</dt>
                  <dd>
                    {round(selected.head)} {labels.head}
                  </dd>
                </div>
              </dl>
            </div>
            <svg
              className="performance-chart"
              viewBox={`0 0 ${width} ${height}`}
              role="img"
              aria-labelledby={`${chartId}-title ${chartId}-desc`}
            >
              <title id={`${chartId}-title`}>
                {`${match.model.model} illustrative head versus flow curve / ${match.model.model} 示意扬程-流量曲线`}
              </title>
              <desc id={`${chartId}-desc`}>
                {`The selected duty is ${displayDuty.flow} ${labels.flow} at ${displayDuty.head} ${labels.head}. The shaded region is the model-specific illustrative preferred operating region. / 所选工况为 ${displayDuty.flow} ${labels.flow}、${displayDuty.head} ${labels.head}。阴影区域为该型号的示意优选运行区。`}
              </desc>
              {[0, 0.25, 0.5, 0.75, 1].map((tick) => (
                <g key={`y-${tick}`}>
                  <path
                    d={`M${pad.left} ${y(maxHead * tick)}H${width - pad.right}`}
                    className="chart-gridline"
                  />
                  <text
                    x={pad.left - 12}
                    y={y(maxHead * tick) + 5}
                    textAnchor="end"
                  >
                    {round(maxHead * tick, 0)}
                  </text>
                </g>
              ))}
              {[0, 0.25, 0.5, 0.75, 1].map((tick) => (
                <g key={`x-${tick}`}>
                  <path
                    d={`M${x(maxFlow * tick)} ${pad.top}V${height - pad.bottom}`}
                    className="chart-gridline"
                  />
                  <text
                    x={x(maxFlow * tick)}
                    y={height - pad.bottom + 25}
                    textAnchor="middle"
                  >
                    {round(maxFlow * tick, 0)}
                  </text>
                </g>
              ))}
              <rect
                x={x(porMin)}
                y={pad.top}
                width={Math.max(0, x(porMax) - x(porMin))}
                height={height - pad.top - pad.bottom}
                className="por-band"
              />
              <text
                x={(x(porMin) + x(porMax)) / 2}
                y={52}
                textAnchor="middle"
                className="por-label"
              >
                ILLUSTRATIVE POR / 示意 POR
              </text>
              <path d={line} className="curve-line" />
              {displayCurve.map((point) => (
                <circle
                  key={`${point.flow}-${point.head}`}
                  cx={x(point.flow)}
                  cy={y(point.head)}
                  r="4"
                  className="curve-point"
                >
                  <title>
                    {round(point.flow)} {labels.flow}, {round(point.head)}{" "}
                    {labels.head}
                  </title>
                </circle>
              ))}
              <circle
                cx={x(bep.flow)}
                cy={y(bep.head)}
                r="9"
                className="bep-point"
              />
              <text
                x={x(bep.flow) + 13}
                y={y(bep.head) - 12}
                className="bep-label"
              >
                BEP
              </text>
              <path
                d={`M${x(displayDuty.flow)} ${y(displayDuty.head)}V${height - pad.bottom}`}
                className="duty-guide"
              />
              <circle
                cx={x(displayDuty.flow)}
                cy={y(displayDuty.head)}
                r="10"
                className="duty-point"
              />
              <text
                x={x(displayDuty.flow) + 14}
                y={y(displayDuty.head) + 5}
                className="duty-label"
              >
                DUTY
              </text>
              <text
                x={width / 2}
                y={height - 10}
                textAnchor="middle"
                className="axis-label"
              >
                {`Flow / 流量 (${labels.flow})`}
              </text>
              <text
                x="18"
                y={height / 2}
                textAnchor="middle"
                transform={`rotate(-90 18 ${height / 2})`}
                className="axis-label"
              >
                {`Head / 扬程 (${labels.head})`}
              </text>
            </svg>
            <div className="chart-legend" aria-hidden="true">
              <span className="legend-curve">Q–H curve</span>
              <span className="legend-duty">Selected duty</span>
              <span className="legend-bep">BEP</span>
              <span className="legend-por">Illustrative POR</span>
            </div>
          </div>
          <aside className="duty-analysis">
            <span className="analysis-number">{match.score.total}</span>
            <p>illustrative match score</p>
            <dl>
              <div>
                <dt>Flow vs BEP</dt>
                <dd>{round(match.relativeBepDistance * 100)}% away</dd>
              </div>
              <div>
                <dt>Interpolated efficiency</dt>
                <dd>{round(match.point.efficiencyPct)}%</dd>
              </div>
              <div>
                <dt>Interpolated NPSHr</dt>
                <dd>
                  {round(selected.npsh)} {labels.npsh}
                </dd>
              </div>
              <div>
                <dt>Shaft power</dt>
                <dd>
                  {round(selected.power)} {labels.power}
                </dd>
              </div>
            </dl>
            <p className="analysis-warning">
              NPSHr is a pump characteristic. Confirm NPSHa, margin and suction
              conditions with application engineering.
            </p>
          </aside>
        </div>

        <div className="mini-chart-grid">
          <MiniChart
            model={match.model}
            metric="efficiencyPct"
            label="Efficiency"
            unit="%"
            unitSystem={unitSystem}
          />
          <MiniChart
            model={match.model}
            metric="npshrM"
            label="NPSHr"
            unit={labels.npsh}
            unitSystem={unitSystem}
          />
          <MiniChart
            model={match.model}
            metric="shaftPowerKw"
            label="Shaft power"
            unit={labels.power}
            unitSystem={unitSystem}
          />
        </div>

        <details className="curve-table">
          <summary>Open accessible curve data table</summary>
          <section
            className="table-wrap"
            aria-label="Curve data table / 曲线数据表"
          >
            <table>
              <caption>
                <Bi
                  en={`${match.model.model} illustrative 50 Hz curve data in ${unitSystem === "metric" ? "metric" : "US"} units`}
                  zh={`${match.model.model} 50 Hz 示意曲线数据（${unitSystem === "metric" ? "公制" : "美制"}单位）`}
                />
              </caption>
              <thead>
                <tr>
                  <th scope="col">Flow ({labels.flow})</th>
                  <th scope="col">Head ({labels.head})</th>
                  <th scope="col">Efficiency (%)</th>
                  <th scope="col">NPSHr ({labels.npsh})</th>
                  <th scope="col">Shaft power ({labels.power})</th>
                </tr>
              </thead>
              <tbody>
                {displayCurve.map((point) => (
                  <tr key={`${point.flow}-${point.head}`}>
                    <td>{round(point.flow)}</td>
                    <td>{round(point.head)}</td>
                    <td>{round(point.efficiency)}</td>
                    <td>{round(point.npsh)}</td>
                    <td>{round(point.power)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        </details>
      </div>
    </section>,
  );
}

function FieldError({ message }: { message?: string }) {
  return message
    ? bilingualize(<span className="field-error">{message}</span>)
    : null;
}

const optionalNumber = {
  setValueAs: (value: string) => (value === "" ? undefined : Number(value)),
};

function TechnicalRfq({
  duty,
  selectedModelId,
  conditions,
}: {
  duty?: DisplayDuty;
  selectedModelId?: string;
  conditions: Conditions;
}) {
  const [step, setStep] = useState(0);
  const [attachment, setAttachment] = useState<File>();
  const [attachmentError, setAttachmentError] = useState<string>();
  const [serverError, setServerError] = useState<string>();
  const [summary, setSummary] = useState<string>();
  const [copied, setCopied] = useState(false);
  const { reviewQuestions } = useDecisionScene();
  const {
    register,
    handleSubmit,
    setValue,
    trigger,
    formState: { errors, isSubmitting },
  } = useForm<RfqValues>({
    resolver: zodResolver(rfqSchema),
    defaultValues: {
      selectedModelId: "",
      unitSystem: "metric",
      flow: 40,
      head: 45,
      frequencyHz: 50,
      fluid: "Clean water",
      temperature: 20,
      vfdRequired: false,
      quantity: 1,
      consent: false,
    },
  });

  useEffect(() => {
    if (!duty) return;
    setValue("unitSystem", duty.unitSystem);
    setValue("flow", duty.flow);
    setValue("head", duty.head);
    setValue("frequencyHz", duty.frequencyHz);
    setValue("temperature", duty.temperature);
    setValue("fluid", conditions.fluid);
    setValue(
      "npsha",
      conditions.npsha === "" ? undefined : Number(conditions.npsha),
    );
    setValue("specificGravity", Number(conditions.specificGravity));
    setValue("viscosityCst", Number(conditions.viscosityCst));
    setValue("materialPreference", conditions.materialPreference);
    setValue("vfdRequired", conditions.vfdRequired);
  }, [conditions, duty, setValue]);

  useEffect(() => {
    setValue("selectedModelId", selectedModelId || "");
  }, [selectedModelId, setValue]);

  useEffect(() => {
    setValue("reviewQuestions", reviewQuestions);
  }, [reviewQuestions, setValue]);

  async function nextStep() {
    if (step === 1) {
      const fileError = validateAttachment(attachment);
      setAttachmentError(fileError);
      if (fileError) return;
    }
    const valid = await trigger([...rfqStepFields[step]], {
      shouldFocus: true,
    });
    if (valid) setStep((current) => Math.min(2, current + 1));
  }

  function onAttachment(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    const error = validateAttachment(file);
    setAttachment(file);
    setAttachmentError(error);
  }

  async function submit(values: RfqValues) {
    const fileError = validateAttachment(attachment);
    if (fileError) {
      setAttachmentError(fileError);
      setStep(1);
      return;
    }
    setServerError(undefined);
    const formData = new FormData();
    formData.set("payload", JSON.stringify(values));
    if (attachment) formData.set("attachment", attachment);
    const response = await fetch("/api/rfq", {
      method: "POST",
      body: formData,
    });
    const result = (await response.json()) as {
      summary?: string;
      error?: string;
    };
    if (!response.ok || !result.summary) {
      setServerError(result.error || "The local demo route rejected this RFQ.");
      return;
    }
    setSummary(result.summary);
  }

  async function copySummary() {
    if (!summary) return;
    try {
      await navigator.clipboard.writeText(summary);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  function downloadSummary() {
    if (!summary) return;
    const url = URL.createObjectURL(
      new Blob([summary], { type: "text/plain" }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "AsterFlow_NX_Technical_RFQ_CONCEPT.txt";
    link.click();
    URL.revokeObjectURL(url);
  }

  if (summary) {
    return bilingualize(
      <section id="rfq" className="rfq-section">
        <div className="section-shell section-block">
          <div className="rfq-success">
            <span className="success-mark" aria-hidden="true">
              ✓
            </span>
            <p className="kicker">Local demo submission accepted</p>
            <h2>The technical context stayed intact.</h2>
            <p>
              No email, CRM or quotation backend is connected. Use this
              deterministic summary as the handoff artifact.
            </p>
            <pre>{summary}</pre>
            <div className="success-actions">
              <button
                className="button button-accent"
                type="button"
                onClick={copySummary}
              >
                {copied ? "Copied" : "Copy summary"}
              </button>
              <button
                className="button button-ghost"
                type="button"
                onClick={downloadSummary}
              >
                Download .txt
              </button>
            </div>
          </div>
        </div>
      </section>,
    );
  }

  return bilingualize(
    <section id="rfq" className="rfq-section">
      <div className="section-shell section-block">
        <div className="section-heading split-heading">
          <div>
            <p className="kicker">04 / Technical RFQ</p>
            <h2>Send the decision context, not “Contact us”.</h2>
          </div>
          <p>
            Three short steps inherit the duty and selected model. The local
            demo route validates the same schema and stores nothing.
          </p>
        </div>

        <RfqQuestionManifest />

        <div className="rfq-shell">
          <ol className="rfq-progress" aria-label="RFQ progress">
            {["Selected duty", "System & configuration", "Contact"].map(
              (label, index) => (
                <li
                  key={label}
                  className={
                    index === step ? "current" : index < step ? "complete" : ""
                  }
                >
                  <button
                    type="button"
                    disabled={index > step}
                    aria-current={index === step ? "step" : undefined}
                    onClick={() => setStep(index)}
                  >
                    <span>{index < step ? "✓" : index + 1}</span>
                    {label}
                  </button>
                </li>
              ),
            )}
          </ol>

          <form onSubmit={handleSubmit(submit)} noValidate>
            {step === 0 && (
              <fieldset>
                <legend>Step 1 — Selected duty</legend>
                <p className="step-intro">
                  Model can remain blank when the selector returns Engineering
                  review.
                </p>
                <div className="form-grid">
                  <label className="span-2">
                    <span>Selected concept model</span>
                    <select {...register("selectedModelId")}>
                      <option value="">Engineering review requested</option>
                      {nxSeries.productModels.map((model) => (
                        <option value={model.id} key={model.id}>
                          {model.model}
                        </option>
                      ))}
                    </select>
                    <FieldError message={errors.selectedModelId?.message} />
                  </label>
                  <label>
                    <span>Flow</span>
                    <input
                      type="number"
                      step="any"
                      {...register("flow", { valueAsNumber: true })}
                    />
                    <FieldError message={errors.flow?.message} />
                  </label>
                  <label>
                    <span>Head</span>
                    <input
                      type="number"
                      step="any"
                      {...register("head", { valueAsNumber: true })}
                    />
                    <FieldError message={errors.head?.message} />
                  </label>
                  <label>
                    <span>Frequency</span>
                    <select
                      {...register("frequencyHz", {
                        setValueAs: (value) => Number(value),
                      })}
                    >
                      <option value="50">50 Hz</option>
                      <option value="60">60 Hz — review</option>
                    </select>
                    <FieldError message={errors.frequencyHz?.message} />
                  </label>
                  <label>
                    <span>Fluid</span>
                    <input {...register("fluid")} />
                    <FieldError message={errors.fluid?.message} />
                  </label>
                  <label>
                    <span>Fluid temperature</span>
                    <input
                      type="number"
                      step="any"
                      {...register("temperature", { valueAsNumber: true })}
                    />
                    <FieldError message={errors.temperature?.message} />
                  </label>
                </div>
              </fieldset>
            )}

            {step === 1 && (
              <fieldset>
                <legend>Step 2 — System and configuration</legend>
                <p className="step-intro">
                  Quantity and installation country are required. Unknown
                  engineering conditions can remain blank for review.
                </p>
                <div className="form-grid">
                  <label>
                    <span>NPSHa</span>
                    <input
                      type="number"
                      min="0"
                      step="any"
                      {...register("npsha", optionalNumber)}
                    />
                    <FieldError message={errors.npsha?.message} />
                  </label>
                  <label>
                    <span>Suction condition</span>
                    <input
                      placeholder="Tank level, lift, pressure…"
                      {...register("suctionCondition")}
                    />
                  </label>
                  <label>
                    <span>Specific gravity</span>
                    <input
                      type="number"
                      min="0.01"
                      step="any"
                      {...register("specificGravity", optionalNumber)}
                    />
                    <FieldError message={errors.specificGravity?.message} />
                  </label>
                  <label>
                    <span>Viscosity (cSt)</span>
                    <input
                      type="number"
                      min="0.01"
                      step="any"
                      {...register("viscosityCst", optionalNumber)}
                    />
                    <FieldError message={errors.viscosityCst?.message} />
                  </label>
                  <label>
                    <span>Solids (%)</span>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="any"
                      {...register("solidsPct", optionalNumber)}
                    />
                    <FieldError message={errors.solidsPct?.message} />
                  </label>
                  <label>
                    <span>Material preference</span>
                    <input {...register("materialPreference")} />
                  </label>
                  <label>
                    <span>Seal preference</span>
                    <input {...register("sealPreference")} />
                  </label>
                  <label>
                    <span>Voltage (V)</span>
                    <input
                      type="number"
                      min="1"
                      {...register("voltageV", optionalNumber)}
                    />
                    <FieldError message={errors.voltageV?.message} />
                  </label>
                  <label>
                    <span>Phase</span>
                    <select
                      {...register("phase", {
                        setValueAs: (value) =>
                          value === "" ? undefined : Number(value),
                      })}
                    >
                      <option value="">Review</option>
                      <option value="1">1 phase</option>
                      <option value="3">3 phase</option>
                    </select>
                  </label>
                  <label>
                    <span>Motor enclosure</span>
                    <input
                      placeholder="e.g. TEFC requirement"
                      {...register("motorEnclosure")}
                    />
                  </label>
                  <label className="check-field">
                    <input type="checkbox" {...register("vfdRequired")} />
                    <span>VFD required</span>
                  </label>
                  <label>
                    <span>Quantity *</span>
                    <input
                      type="number"
                      min="1"
                      {...register("quantity", { valueAsNumber: true })}
                    />
                    <FieldError message={errors.quantity?.message} />
                  </label>
                  <label>
                    <span>Installation country *</span>
                    <input {...register("installationCountry")} />
                    <FieldError message={errors.installationCountry?.message} />
                  </label>
                  <label>
                    <span>Target date</span>
                    <input type="date" {...register("targetDate")} />
                  </label>
                  <label className="span-2">
                    <span>Required standards</span>
                    <input
                      placeholder="List project or market requirements"
                      {...register("requiredStandards")}
                    />
                  </label>
                  <label className="span-2">
                    <span>
                      Attach one technical file (PDF, JPEG or PNG · max 10 MB)
                    </span>
                    <input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png"
                      onChange={onAttachment}
                    />
                    <FieldError message={attachmentError} />
                  </label>
                </div>
              </fieldset>
            )}

            {step === 2 && (
              <fieldset>
                <legend>Step 3 — Contact and project stage</legend>
                <p className="step-intro">
                  This prototype uses the details only to validate the local
                  form. Nothing is persisted or sent.
                </p>
                <div className="form-grid">
                  <label>
                    <span>Name *</span>
                    <input autoComplete="name" {...register("name")} />
                    <FieldError message={errors.name?.message} />
                  </label>
                  <label>
                    <span>Company *</span>
                    <input
                      autoComplete="organization"
                      {...register("company")}
                    />
                    <FieldError message={errors.company?.message} />
                  </label>
                  <label>
                    <span>Business email *</span>
                    <input
                      type="email"
                      autoComplete="email"
                      {...register("businessEmail")}
                    />
                    <FieldError message={errors.businessEmail?.message} />
                  </label>
                  <label>
                    <span>Phone / WhatsApp</span>
                    <input
                      type="tel"
                      autoComplete="tel"
                      {...register("phone")}
                    />
                  </label>
                  <label>
                    <span>Country *</span>
                    <input
                      autoComplete="country-name"
                      {...register("contactCountry")}
                    />
                    <FieldError message={errors.contactCountry?.message} />
                  </label>
                  <label>
                    <span>Role</span>
                    <input
                      autoComplete="organization-title"
                      {...register("role")}
                    />
                  </label>
                  <label>
                    <span>Project stage</span>
                    <select
                      {...register("projectStage", {
                        setValueAs: (value) =>
                          value === "" ? undefined : value,
                      })}
                    >
                      <option value="">Select if known</option>
                      <option value="concept">Concept</option>
                      <option value="design">Design</option>
                      <option value="tender">Tender</option>
                      <option value="procurement">Procurement</option>
                      <option value="replacement">Replacement</option>
                    </select>
                    <FieldError message={errors.projectStage?.message} />
                  </label>
                  <label className="check-field consent-field span-2">
                    <input type="checkbox" {...register("consent")} />
                    <span>
                      I consent to this local prototype processing the entered
                      data to generate a technical summary.
                    </span>
                    <FieldError message={errors.consent?.message} />
                  </label>
                </div>
              </fieldset>
            )}

            {serverError && (
              <p className="form-alert" role="alert">
                {serverError}
              </p>
            )}

            <div className="form-actions">
              {step > 0 && (
                <button
                  className="button button-outline"
                  type="button"
                  onClick={() => setStep(step - 1)}
                >
                  Back
                </button>
              )}
              {step < 2 ? (
                <button
                  className="button button-accent"
                  type="button"
                  onClick={nextStep}
                >
                  Continue
                </button>
              ) : (
                <button
                  className="button button-accent"
                  type="submit"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Validating…" : "Generate technical summary"}
                </button>
              )}
            </div>
          </form>
          <aside className="rfq-boundary">
            <strong>Prototype boundary</strong>
            <ul>
              <li>No email or CRM connection</li>
              <li>No contact data persistence</li>
              <li>Attachment bytes are discarded</li>
              <li>No quote, lead time or engineering approval</li>
            </ul>
          </aside>
        </div>
      </div>
    </section>,
  );
}

export default function DecisionFlow({ children }: { children: ReactNode }) {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric");
  const [conditions, setConditions] = useState(defaultConditions);
  const [canonicalDuty, setCanonicalDuty] = useState<MetricDuty>();
  const [outcome, setOutcome] =
    useState<ReturnType<typeof getPreliminaryShortlist>>();
  const [selectedModelId, setSelectedModelId] = useState<string>();
  const { clearReviewQuestions, setCounterfactual, setScene } =
    useDecisionScene();

  function submitDuty(duty: DisplayDuty) {
    const nextOutcome = getPreliminaryShortlist(duty);
    setCanonicalDuty(toMetricDuty(duty));
    setOutcome(nextOutcome);
    setSelectedModelId(nextOutcome.matches[0]?.model.id);
    setCounterfactual("none");
    clearReviewQuestions();
    setScene({
      evidenceSkin:
        nextOutcome.coverage === "missing-frequency"
          ? "review"
          : nextOutcome.matches.length > 0
            ? "illustrative"
            : "uncovered",
      focus:
        nextOutcome.coverage === "missing-frequency"
          ? "frequency"
          : "hydraulic",
    });
    requestAnimationFrame(() =>
      document
        .getElementById("shortlist")
        ?.scrollIntoView({ behavior: "smooth" }),
    );
  }

  function selectModel(modelId: string, destination: "performance" | "rfq") {
    setSelectedModelId(modelId);
    setScene({ focus: destination === "performance" ? "hydraulic" : "rfq" });
    requestAnimationFrame(() =>
      document
        .getElementById(destination)
        ?.scrollIntoView({ behavior: "smooth" }),
    );
  }

  const selectedMatch = outcome?.matches.find(
    (match) => match.model.id === selectedModelId,
  );
  const displayedDuty = canonicalDuty
    ? fromMetricDuty(canonicalDuty, unitSystem)
    : undefined;

  return bilingualize(
    <>
      <section
        className="story-chapter story-chapter-2"
        data-page="02"
        aria-label="Duty and preliminary shortlist"
      >
        <div className="chapter-panel chapter-left chapter-scroll">
          <SelectorPanel
            unitSystem={unitSystem}
            onUnitChange={(nextUnit) => {
              setUnitSystem(nextUnit);
              setScene({ focus: "frequency" });
            }}
            onSubmit={submitDuty}
            conditions={conditions}
            onConditionsChange={setConditions}
          />
        </div>
        <div className="chapter-panel chapter-right chapter-scroll">
          {outcome ? (
            <Shortlist
              outcome={outcome}
              unitSystem={unitSystem}
              selectedModelId={selectedModelId}
              onSelect={selectModel}
              conditions={conditions}
            />
          ) : (
            <div className="chapter-placeholder">
              <p className="kicker">02 / Preliminary shortlist</p>
              <h2>Enter one duty point to reveal the shortlist.</h2>
              <p>
                The center product remains fixed while the decision evidence
                changes around it.
              </p>
            </div>
          )}
        </div>
      </section>

      <section
        className="story-chapter story-chapter-3"
        data-page="03"
        aria-label="Performance and evidence"
      >
        <div className="chapter-panel chapter-left chapter-scroll">
          {selectedMatch && canonicalDuty ? (
            <Performance
              match={selectedMatch}
              duty={canonicalDuty}
              unitSystem={unitSystem}
            />
          ) : (
            <div className="chapter-placeholder">
              <p className="kicker">03 / Interactive performance</p>
              <h2>The curve waits for a valid 50 Hz shortlist.</h2>
              <p>
                A 60 Hz request stays in Engineering review and never receives a
                synthetic curve.
              </p>
            </div>
          )}
        </div>
        <div className="chapter-panel chapter-right chapter-scroll">
          {children}
        </div>
      </section>

      <section
        className="story-chapter story-chapter-4"
        data-page="04"
        aria-label="Technical RFQ and case evidence"
      >
        <div className="chapter-panel chapter-left chapter-scroll">
          <TechnicalRfq
            duty={displayedDuty}
            selectedModelId={selectedModelId}
            conditions={conditions}
          />
        </div>
        <div
          id="evidence"
          className="chapter-panel chapter-right case-link-compact"
        >
          <p className="kicker">Case evidence</p>
          <h2>Seven cards prove how the decision interface was built.</h2>
          <p>
            Business problem, buyer questions, truth contract, selection policy,
            curve reading, RFQ handoff and positioning remain available as one
            evidence stream.
          </p>
          <a className="button button-outline" href="/case-study">
            Open seven-card evidence
          </a>
          <div className="proof-metrics compact-proof">
            <div>
              <strong>50 Hz</strong>
              <span>illustrative dataset</span>
            </div>
            <div>
              <strong>60 Hz</strong>
              <span>fail-closed review</span>
            </div>
            <div>
              <strong>3 steps</strong>
              <span>context-preserving RFQ</span>
            </div>
            <div>
              <strong>0</strong>
              <span>real selection claims</span>
            </div>
          </div>
        </div>
      </section>
    </>,
  );
}

export { buildRfqSummary };
