"use client";

import { useState } from "react";
import {
  conversions,
  fromMetricDuty,
  type MetricDuty,
  round,
  type ShortlistOutcome,
  type UnitSystem,
} from "@/domain/pump";
import { Bi } from "@/features/Bilingual";
import {
  type CounterfactualMode,
  useDecisionScene,
} from "@/features/nx-series/DecisionSceneContext";

type RequirementAction = "confirm" | "clarify" | "exclude";

function modelName(modelId: string) {
  return modelId.replace("nx-", "NX ").replace(/-50$/, "").replaceAll("-", "-");
}

const exclusionCopy = {
  "insufficient-head": {
    en: "Available illustrative head is below the entered duty.",
    zh: "可用示意扬程低于已输入工况。",
  },
  "temperature-out-of-range": {
    en: "Entered temperature sits outside the model concept range.",
    zh: "输入温度超出该型号概念范围。",
  },
  "curve-out-of-range": {
    en: "Entered flow falls outside the local concept curve.",
    zh: "输入流量超出本地概念曲线。",
  },
} as const;

export function RejectionRail({ outcome }: { outcome: ShortlistOutcome }) {
  const rejected = outcome.evaluations.filter(
    (evaluation) => evaluation.eligibility !== "eligible",
  );

  if (rejected.length === 0) return null;

  return (
    <section className="rejection-rail" aria-label="Rejection rail / 淘汰轨道">
      <div className="trace-heading">
        <div>
          <Bi className="trace-index" en="Rejection rail" zh="淘汰轨道" />
          <h3>
            <Bi en="Eliminate before comparing." zh="先淘汰，再比较。" />
          </h3>
        </div>
        <Bi
          en="Each retained reason comes from the same local concept fixture."
          zh="每项保留理由均来自同一份本地概念数据夹具。"
        />
      </div>
      <ul>
        {rejected.map((evaluation) => {
          const copy =
            exclusionCopy[evaluation.eligibility as keyof typeof exclusionCopy];
          return (
            <li
              key={evaluation.modelId}
              data-rejection={evaluation.eligibility}
            >
              <strong>{modelName(evaluation.modelId)}</strong>
              <Bi en={copy.en} zh={copy.zh} />
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export function UnitParityPanel({
  duty,
  unitSystem,
}: {
  duty: MetricDuty;
  unitSystem: UnitSystem;
}) {
  const [open, setOpen] = useState(false);
  const { setScene } = useDecisionScene();
  const display = fromMetricDuty(duty, unitSystem);
  const rows = [
    {
      name: "Flow / 流量",
      source: `${round(duty.flowM3h)} m³/h`,
      derived: `${round(conversions.m3hToGpm(duty.flowM3h), 2)} US gpm`,
      roundTrip: `${round(conversions.gpmToM3h(conversions.m3hToGpm(duty.flowM3h)), 4)} m³/h`,
    },
    {
      name: "Head / 扬程",
      source: `${round(duty.headM)} m`,
      derived: `${round(conversions.mToFt(duty.headM), 2)} ft`,
      roundTrip: `${round(conversions.ftToM(conversions.mToFt(duty.headM)), 4)} m`,
    },
    {
      name: "Temperature / 温度",
      source: `${round(duty.temperatureC)} °C`,
      derived: `${round(conversions.cToF(duty.temperatureC), 2)} °F`,
      roundTrip: `${round(conversions.fToC(conversions.cToF(duty.temperatureC)), 4)} °C`,
    },
  ];

  return (
    <section className="unit-parity" data-unit-system={unitSystem}>
      <div className="trace-heading">
        <div>
          <Bi className="trace-index" en="Semantic twin rail" zh="语义双轨" />
          <h3>
            <Bi
              en="Keep the source, conversion and residue visible."
              zh="让原值、换算与残差保持可见。"
            />
          </h3>
        </div>
        <button
          className="trace-button"
          type="button"
          aria-expanded={open}
          onClick={() => {
            setOpen((current) => !current);
            setScene({ focus: "frequency" });
          }}
        >
          <Bi
            en={open ? "Close unit pair" : "Inspect unit pair"}
            zh={open ? "收起单位对应" : "检查单位对应"}
          />
        </button>
      </div>
      <p className="trace-summary">
        <Bi
          en={`Current display: ${display.unitSystem === "metric" ? "metric" : "US"}. Frequency remains ${duty.frequencyHz} Hz.`}
          zh={`当前显示：${display.unitSystem === "metric" ? "公制" : "美制"}。频率保持为 ${duty.frequencyHz} Hz。`}
        />
      </p>
      {open && (
        <>
          <div className="parity-grid">
            {rows.map((row) => (
              <article key={row.name}>
                <strong>{row.name}</strong>
                <span>
                  <Bi en="Source" zh="原值" /> {row.source}
                </span>
                <span>
                  <Bi en="Derived" zh="换算值" /> {row.derived}
                </span>
                <span>
                  <Bi en="Round trip" zh="反算" /> {row.roundTrip}
                </span>
              </article>
            ))}
          </div>
          <p className="frequency-parity">
            <Bi
              en={
                duty.frequencyHz === 50
                  ? "50 Hz stays an illustrative concept dataset; unit conversion does not create a 60 Hz curve."
                  : "60 Hz remains Engineering review; unit conversion does not create performance evidence."
              }
              zh={
                duty.frequencyHz === 50
                  ? "50 Hz 仍为示意性概念数据集；单位换算不会生成 60 Hz 曲线。"
                  : "60 Hz 仍需工程复核；单位换算不会生成性能证据。"
              }
            />
          </p>
        </>
      )}
    </section>
  );
}

export function TenderRedline({
  duty,
  outcome,
  fluid,
  materialPreference,
}: {
  duty: MetricDuty;
  outcome: ShortlistOutcome;
  fluid: string;
  materialPreference: string;
}) {
  const [actions, setActions] = useState<Record<string, RequirementAction>>({});
  const { reviewQuestions, setScene, toggleReviewQuestion } =
    useDecisionScene();
  const covered = outcome.coverage === "covered" && outcome.matches.length > 0;
  const rows = [
    {
      key: "duty",
      focus: "hydraulic" as const,
      clause: `${round(duty.flowM3h)} m³/h at ${round(duty.headM)} m`,
      evidence: covered
        ? "Local illustrative curve coverage is present."
        : "No local illustrative curve coverage is present.",
      evidenceZh: covered
        ? "本地示意曲线覆盖已存在。"
        : "本地示意曲线覆盖尚未存在。",
      state: covered ? "MATCH" : "REDLINE",
      stateZh: covered ? "对应" : "存在差异",
      question: "Confirm flow and head against the manufacturer curve.",
      questionZh: "请依据制造商曲线确认流量与扬程。",
    },
    {
      key: "fluid",
      focus: "hydraulic" as const,
      clause: fluid,
      evidence:
        fluid === "Clean water"
          ? "Clean-water circulation is within this concept scope."
          : "The entered fluid remains an Engineering review item.",
      evidenceZh:
        fluid === "Clean water"
          ? "清水循环处于本概念范围内。"
          : "输入介质仍是工程复核项目。",
      state: fluid === "Clean water" ? "MATCH" : "CLARIFY",
      stateZh: fluid === "Clean water" ? "对应" : "需澄清",
      question: `Confirm fluid compatibility for ${fluid}.`,
      questionZh: `请确认 ${fluid} 的介质兼容性。`,
    },
    {
      key: "frequency",
      focus: "frequency" as const,
      clause: `${duty.frequencyHz} Hz`,
      evidence:
        duty.frequencyHz === 50
          ? "50 Hz is an illustrative concept dataset only."
          : "60 Hz is not covered by a concept curve.",
      evidenceZh:
        duty.frequencyHz === 50
          ? "50 Hz 仅为示意性概念数据集。"
          : "60 Hz 未被概念曲线覆盖。",
      state: duty.frequencyHz === 50 ? "CAVEAT" : "REVIEW",
      stateZh: duty.frequencyHz === 50 ? "附带条件" : "需复核",
      question:
        duty.frequencyHz === 50
          ? "Request the manufacturer curve and final duty confirmation."
          : "Request a 60 Hz curve for Engineering review.",
      questionZh:
        duty.frequencyHz === 50
          ? "请求制造商曲线与最终工况确认。"
          : "请求 60 Hz 曲线进行工程复核。",
    },
    {
      key: "material",
      focus: "rfq" as const,
      clause: materialPreference || "Material not specified",
      evidence: materialPreference
        ? "Material preference is captured as RFQ intent, not a supply confirmation."
        : "Material remains an RFQ question.",
      evidenceZh: materialPreference
        ? "材料偏好作为 RFQ 意图被记录，不代表供货确认。"
        : "材料仍是 RFQ 问题。",
      state: materialPreference ? "INTENT" : "CLARIFY",
      stateZh: materialPreference ? "意图" : "需澄清",
      question: materialPreference
        ? `Confirm material availability for ${materialPreference}.`
        : "Confirm wetted-material requirement.",
      questionZh: materialPreference
        ? `请确认 ${materialPreference} 的材料供货可行性。`
        : "请确认过流材料要求。",
    },
  ];

  function setAction(row: (typeof rows)[number], action: RequirementAction) {
    const attached = reviewQuestions.some((item) => item.key === row.key);
    if (action === "clarify" && !attached) {
      toggleReviewQuestion({
        key: row.key,
        en: row.question,
        zh: row.questionZh,
      });
    }
    if (action !== "clarify" && attached) {
      toggleReviewQuestion({
        key: row.key,
        en: row.question,
        zh: row.questionZh,
      });
    }
    setActions((current) => ({ ...current, [row.key]: action }));
    setScene({ focus: row.focus });
  }

  return (
    <section
      className="tender-redline"
      aria-label="Requirement redline / 需求红线"
    >
      <div className="trace-heading">
        <div>
          <Bi
            className="trace-index"
            en="Living tender redline"
            zh="动态需求红线"
          />
          <h3>
            <Bi
              en="Compare the requirement before a model name."
              zh="先核对需求，再讨论型号。"
            />
          </h3>
        </div>
        <Bi
          en="Manual clause comparison — no automatic engineering interpretation."
          zh="人工条款对照——不进行自动工程判读。"
        />
      </div>
      <ul className="redline-table">
        {rows.map((row) => {
          const action = actions[row.key];
          return (
            <li
              key={row.key}
              data-redline-state={row.state.toLowerCase()}
              data-redline-action={action || "pending"}
            >
              <div className="redline-clause">
                <span>
                  <Bi en="Requirement clause" zh="需求条款" />
                </span>
                <strong>{row.clause}</strong>
              </div>
              <div className="redline-evidence">
                <span>
                  <Bi en="Current evidence" zh="当前证据" />
                </span>
                <Bi en={row.evidence} zh={row.evidenceZh} />
              </div>
              <div className="redline-state">
                <strong>{row.state}</strong>
                <span>{row.stateZh}</span>
              </div>
              <fieldset className="redline-actions">
                <legend className="sr-only">
                  {row.clause} actions / {row.clause} 操作
                </legend>
                {(["confirm", "clarify", "exclude"] as RequirementAction[]).map(
                  (nextAction) => (
                    <button
                      className={action === nextAction ? "active" : ""}
                      key={nextAction}
                      type="button"
                      onClick={() => setAction(row, nextAction)}
                    >
                      <Bi
                        en={
                          nextAction === "confirm"
                            ? "Confirm"
                            : nextAction === "clarify"
                              ? "Clarify"
                              : "Exclude"
                        }
                        zh={
                          nextAction === "confirm"
                            ? "确认"
                            : nextAction === "clarify"
                              ? "澄清"
                              : "排除"
                        }
                      />
                    </button>
                  ),
                )}
              </fieldset>
              {action === "clarify" && (
                <p className="redline-question">
                  <Bi en={row.question} zh={row.questionZh} />
                </p>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export function CounterfactualRail() {
  const { counterfactual, setCounterfactual, setScene } = useDecisionScene();
  const active = counterfactual !== "none";
  const actionText =
    counterfactual === "remove-flow"
      ? { en: "Flow input removed", zh: "流量输入已移除" }
      : { en: "Head constraint raised by 10 m", zh: "扬程约束提高 10 m" };

  function activate(mode: Exclude<CounterfactualMode, "none">) {
    setCounterfactual(mode);
    setScene({ evidenceSkin: "uncovered", focus: "hydraulic" });
  }

  function reset() {
    setCounterfactual("none");
    setScene({ evidenceSkin: "illustrative", focus: "hydraulic" });
  }

  return (
    <section className="counterfactual-rail" data-active={active}>
      <div className="trace-heading">
        <div>
          <Bi
            className="trace-index"
            en="Counterfactual trace"
            zh="反事实追踪"
          />
          <h3>
            <Bi
              en="See which context would be withdrawn."
              zh="查看哪些上下文会被撤销。"
            />
          </h3>
        </div>
        <Bi
          en="This what-if trace does not rewrite the entered duty."
          zh="此反事实追踪不会改写已输入工况。"
        />
      </div>
      {active ? (
        <div className="counterfactual-impact" role="status">
          <p>
            <Bi en={actionText.en} zh={actionText.zh} />
          </p>
          <ol>
            <li>
              <Bi
                en="Duty input — withdrawn in the trace"
                zh="工况输入——在追踪中被撤销"
              />
            </li>
            <li>
              <Bi
                en="Preliminary shortlist — withheld"
                zh="初步候选——暂不显示"
              />
            </li>
            <li>
              <Bi
                en="Performance view — Engineering review only"
                zh="性能视图——仅保留工程复核"
              />
            </li>
            <li>
              <Bi
                en="Technical RFQ — carry a missing-input note"
                zh="技术 RFQ——携带缺失输入说明"
              />
            </li>
          </ol>
          <button className="trace-button" type="button" onClick={reset}>
            <Bi en="Restore entered duty" zh="恢复已输入工况" />
          </button>
        </div>
      ) : (
        <div className="counterfactual-actions">
          <button
            className="trace-button"
            type="button"
            onClick={() => activate("remove-flow")}
          >
            <Bi en="Remove flow input" zh="移除流量输入" />
          </button>
          <button
            className="trace-button"
            type="button"
            onClick={() => activate("raise-head")}
          >
            <Bi en="Raise head constraint" zh="提高扬程约束" />
          </button>
        </div>
      )}
    </section>
  );
}

export function RfqQuestionManifest() {
  const { reviewQuestions } = useDecisionScene();
  if (reviewQuestions.length === 0) return null;

  return (
    <aside className="rfq-question-manifest" aria-live="polite">
      <Bi
        className="trace-index"
        en="Open question manifest"
        zh="未决问题清单"
      />
      <h3>
        <Bi
          en="Carry unresolved clauses forward."
          zh="将未决条款带入下一步。"
        />
      </h3>
      <ul>
        {reviewQuestions.map((question) => (
          <li key={question.key}>
            <Bi en={question.en} zh={question.zh} />
          </li>
        ))}
      </ul>
      <Bi
        en="These are review questions, not engineering conclusions."
        zh="这些是复核问题，不是工程结论。"
      />
    </aside>
  );
}
