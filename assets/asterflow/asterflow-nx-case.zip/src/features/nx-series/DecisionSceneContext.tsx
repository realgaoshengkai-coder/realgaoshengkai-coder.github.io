"use client";

import {
  createContext,
  type ReactNode,
  useContext,
  useMemo,
  useState,
} from "react";

export type EvidenceSkin = "baseline" | "illustrative" | "review" | "uncovered";

export type SceneFocus = "overview" | "hydraulic" | "frequency" | "rfq";

export type CounterfactualMode = "none" | "remove-flow" | "raise-head";

export interface ReviewQuestion {
  key: string;
  en: string;
  zh: string;
}

interface DecisionSceneContextValue {
  evidenceSkin: EvidenceSkin;
  focus: SceneFocus;
  counterfactual: CounterfactualMode;
  reviewQuestions: ReviewQuestion[];
  setScene: (
    next: Partial<Pick<DecisionSceneContextValue, "evidenceSkin" | "focus">>,
  ) => void;
  setCounterfactual: (mode: CounterfactualMode) => void;
  toggleReviewQuestion: (question: ReviewQuestion) => void;
  clearReviewQuestions: () => void;
}

const DecisionSceneContext = createContext<DecisionSceneContextValue | null>(
  null,
);

export function DecisionSceneProvider({ children }: { children: ReactNode }) {
  const [evidenceSkin, setEvidenceSkin] = useState<EvidenceSkin>("baseline");
  const [focus, setFocus] = useState<SceneFocus>("overview");
  const [counterfactual, setCounterfactual] =
    useState<CounterfactualMode>("none");
  const [reviewQuestions, setReviewQuestions] = useState<ReviewQuestion[]>([]);

  const value = useMemo<DecisionSceneContextValue>(
    () => ({
      evidenceSkin,
      focus,
      counterfactual,
      reviewQuestions,
      setScene(next) {
        if (next.evidenceSkin) setEvidenceSkin(next.evidenceSkin);
        if (next.focus) setFocus(next.focus);
      },
      setCounterfactual,
      toggleReviewQuestion(question) {
        setReviewQuestions((current) =>
          current.some((item) => item.key === question.key)
            ? current.filter((item) => item.key !== question.key)
            : [...current, question],
        );
      },
      clearReviewQuestions() {
        setReviewQuestions([]);
      },
    }),
    [counterfactual, evidenceSkin, focus, reviewQuestions],
  );

  return (
    <DecisionSceneContext.Provider value={value}>
      {children}
    </DecisionSceneContext.Provider>
  );
}

export function useDecisionScene() {
  const value = useContext(DecisionSceneContext);
  if (!value) {
    throw new Error(
      "useDecisionScene must be used within DecisionSceneProvider.",
    );
  }
  return value;
}
