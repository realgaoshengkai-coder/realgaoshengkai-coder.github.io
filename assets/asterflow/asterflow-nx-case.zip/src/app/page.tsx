import { bilingualize } from "@/features/Bilingual";
import DecisionFlow from "@/features/nx-series/DecisionFlow";
import { DecisionSceneProvider } from "@/features/nx-series/DecisionSceneContext";
import PumpScene from "@/features/nx-series/PumpScene";
import StaticSections from "@/features/nx-series/StaticSections";

function ApplicationFit() {
  const fits = [
    [
      "01",
      "HVAC circulation",
      "Chilled-water and condenser-water loops with clean-water-like fluids.",
    ],
    [
      "02",
      "District energy",
      "Closed-loop circulation where duty point and installation data are known.",
    ],
    [
      "03",
      "Industrial cooling",
      "General clean-water heat-rejection and process-cooling loops.",
    ],
  ];

  return bilingualize(
    <div id="application-fit" className="application-compact">
      <div>
        <p className="kicker">Application fit</p>
        <h2>Start with the service boundary.</h2>
        <p>
          This concept narrows the decision to clean-water circulation.
          Conditions outside that envelope move to engineering review instead of
          receiving a guessed match.
        </p>
      </div>
      <div className="fit-grid">
        {fits.map(([number, title, body]) => (
          <article className="fit-card" key={number}>
            <span>{number}</span>
            <h3>{title}</h3>
            <p>{body}</p>
          </article>
        ))}
      </div>
      <div className="review-strip">
        <strong>Engineering review required:</strong>
        <span>
          fire protection · potable-water certification · explosive atmosphere ·
          abrasive solids · aggressive chemicals
        </span>
      </div>
    </div>,
  );
}

export default function Home() {
  return bilingualize(
    <>
      <a className="skip-link" href="#main-content">
        Skip to product content
      </a>
      <header className="site-header">
        <div className="header-inner">
          <a className="brand" href="#top" aria-label="AsterFlow NX home">
            <span aria-hidden="true">A</span>
            <strong>ASTERFLOW</strong>
          </a>
          <nav aria-label="Product navigation">
            <a href="#top">Product</a>
            <a href="#selector">Duty</a>
            <a href="#performance">Curve</a>
            <a href="#rfq">RFQ</a>
          </nav>
          <a className="button button-small button-accent" href="#rfq">
            Request technical quote
          </a>
        </div>
      </header>

      <main id="main-content">
        <div className="product-story">
          <DecisionSceneProvider>
            <PumpScene />
            <div className="story-flow">
              <section
                id="top"
                className="story-chapter story-chapter-1"
                data-page="01"
              >
                <div className="chapter-panel chapter-left hero-copy">
                  <p className="eyebrow">
                    Horizontal single-stage end-suction pump
                  </p>
                  <p className="series-code">NX SERIES / 50 HZ DATASET V1</p>
                  <h1>
                    Match the duty.
                    <em>Then discuss the pump.</em>
                  </h1>
                  <p className="hero-lead">
                    A clearer decision path for HVAC and industrial cooling:
                    preliminary shortlist, inspect the curve, then send the same
                    technical context to application engineering.
                  </p>
                  <div className="hero-actions">
                    <a className="button button-accent" href="#selector">
                      Select by duty point
                    </a>
                    <a
                      className="button button-ghost"
                      href="/samples/AsterFlow_NX_Series_Overview_SAMPLE.pdf"
                      download
                    >
                      Download SAMPLE overview
                    </a>
                  </div>
                  <dl className="hero-facts">
                    <div>
                      <dt>Arrangement</dt>
                      <dd>End-suction / back-pull-out concept</dd>
                    </div>
                    <div>
                      <dt>Application</dt>
                      <dd>HVAC / clean-water cooling</dd>
                    </div>
                    <div>
                      <dt>Frequency coverage</dt>
                      <dd>50 Hz curves · 60 Hz review</dd>
                    </div>
                  </dl>
                </div>
                <div className="chapter-panel chapter-right">
                  <ApplicationFit />
                  <div className="concept-banner">
                    <strong>
                      Illustrative concept data — not for engineering selection.
                    </strong>
                    <span>
                      Final duty, curve, NPSH margin, materials and compliance
                      require manufacturer review.
                    </span>
                  </div>
                </div>
              </section>

              <DecisionFlow>
                <StaticSections />
              </DecisionFlow>
            </div>
          </DecisionSceneProvider>
        </div>
      </main>

      <footer className="site-footer">
        <div className="section-shell footer-grid">
          <div>
            <strong>ASTERFLOW NX</strong>
            <p>Fictional portfolio concept · 2026</p>
          </div>
          <p>
            This unsolicited concept is not an official project for CNP or any
            reference manufacturer. It does not constitute engineering
            selection, procurement advice or a performance guarantee.
          </p>
        </div>
      </footer>
      <a className="mobile-rfq" href="#rfq">
        Request technical quote
      </a>
    </>,
  );
}
