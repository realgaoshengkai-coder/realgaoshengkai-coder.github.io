import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AsterFlow NX Series | End-suction pump concept / 端吸离心泵概念",
  description:
    "A fictional industrial product-page concept with preliminary duty-point shortlisting and a technical RFQ. / 包含工况初选与技术 RFQ 的虚构工业产品页概念。",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
