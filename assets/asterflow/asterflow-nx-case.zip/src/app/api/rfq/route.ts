import { buildRfqSummary, rfqSchema, validateAttachment } from "@/domain/pump";

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const payload = formData.get("payload");
    if (typeof payload !== "string") {
      return Response.json(
        { error: "Missing RFQ payload. / 缺少 RFQ 数据。" },
        { status: 400 },
      );
    }

    const parsed = rfqSchema.safeParse(JSON.parse(payload));
    if (!parsed.success) {
      return Response.json(
        {
          error: "RFQ validation failed. / RFQ 验证失败。",
          fields: parsed.error.flatten().fieldErrors,
        },
        { status: 400 },
      );
    }

    const attachments = formData
      .getAll("attachment")
      .filter(
        (entry): entry is File => entry instanceof File && entry.size > 0,
      );
    if (attachments.length > 1) {
      return Response.json(
        { error: "Attach no more than one file. / 最多附加一个文件。" },
        { status: 400 },
      );
    }
    const attachmentError = validateAttachment(attachments[0]);
    if (attachmentError) {
      return Response.json({ error: attachmentError }, { status: 400 });
    }

    return Response.json(
      {
        status: "received-by-local-demo",
        attachmentReceived: attachments.length === 1,
        summary: buildRfqSummary(parsed.data),
      },
      { status: 202 },
    );
  } catch {
    return Response.json(
      {
        error:
          "The RFQ payload is not valid JSON form data. / RFQ 数据不是有效的 JSON 表单数据。",
      },
      { status: 400 },
    );
  }
}
