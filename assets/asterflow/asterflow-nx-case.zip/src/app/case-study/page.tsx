import Link from "next/link";
import { bilingualize } from "@/features/Bilingual";

const buyerQuestions = [
  "Can this product family serve my clean-water duty?",
  "Which curve covers my required flow and head?",
  "How far is the point from BEP and the stated POR?",
  "What are efficiency, NPSHr and shaft power at that point?",
  "Which material, seal and motor conditions still need review?",
  "Which documents are evidence and which are only SAMPLE?",
  "Can the selected context travel into the RFQ without retyping?",
];

const scoreRows = [
  ["Head margin", "39.1 / 40", "Target is 10% illustrative margin"],
  ["BEP proximity", "35.0 / 35", "40 m³/h equals concept BEP"],
  ["Efficiency", "19.3 / 25", "77% interpolated at duty"],
  ["Total", "93.4 / 100", "Illustrative match score, not confidence"],
];

function CardHeader({ number, label }: { number: string; label: string }) {
  return bilingualize(
    <header className="case-card-header">
      <span>ASTERFLOW NX / CASE EVIDENCE</span>
      <span>
        {number} · {label}
      </span>
    </header>,
  );
}

function CardFooter({ text }: { text: string }) {
  return bilingualize(
    <footer className="case-card-footer">
      <span>{text}</span>
      <span>Fictional portfolio concept · 2026</span>
    </footer>,
  );
}

function StaticCurve() {
  return bilingualize(
    <svg
      className="case-curve"
      viewBox="0 0 800 380"
      role="img"
      aria-labelledby="case-curve-title case-curve-desc"
    >
      <title id="case-curve-title">NX 65-40-200 illustrative Q–H curve</title>
      <desc id="case-curve-desc">
        A static concept curve marks the 40 cubic metres per hour at 45 metre
        duty, the best efficiency point and illustrative preferred operating
        region.
      </desc>
      <rect x="352" y="24" width="146" height="302" className="case-por" />
      <path
        d="M70 77 170 84 270 101 370 128 470 163 570 207 670 261 750 324"
        className="case-curve-line"
      />
      <path d="M70 326H760M70 26V326" className="case-axis" />
      <path d="M370 145V326" className="case-duty-guide" />
      <circle cx="370" cy="145" r="13" className="case-duty-dot" />
      <circle cx="370" cy="128" r="10" className="case-bep-dot" />
      <g className="case-curve-labels">
        <text x="386" y="152">
          REQUESTED DUTY
        </text>
        <text x="386" y="120">
          BEP
        </text>
        <text x="425" y="52" textAnchor="middle">
          ILLUSTRATIVE POR
        </text>
        <text x="415" y="365" textAnchor="middle">
          FLOW
        </text>
        <text x="28" y="180" textAnchor="middle" transform="rotate(-90 28 180)">
          HEAD
        </text>
      </g>
    </svg>,
  );
}

export default function CaseStudy() {
  return bilingualize(
    <main className="case-page">
      <div className="case-toolbar">
        <Link href="/">← Back to interactive product page</Link>
        <span>Seven cards · export size 1080 × 1440</span>
      </div>

      <article className="case-card case-card-1" data-card="01">
        <CardHeader number="01" label="BUSINESS HOOK" />
        <div className="case-card-body">
          <p className="case-kicker">The page was full of specifications.</p>
          <h1>
            But the buyer still had to
            <em> reconstruct the decision.</em>
          </h1>
          <div className="before-after">
            <section>
              <span>PUBLIC BENCHMARK PATTERN</span>
              <h2>Series introduction</h2>
              <div className="fake-lines" aria-hidden="true">
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
              </div>
              <div className="fake-table" aria-hidden="true">
                <i />
                <i />
                <i />
                <i />
              </div>
              <b>Generic inquiry</b>
            </section>
            <span className="case-arrow" aria-hidden="true">
              →
            </span>
            <section>
              <span>REBUILT DECISION PATH</span>
              <h2>Duty input</h2>
              <ol>
                <li>Preliminary shortlist</li>
                <li>Curve + evidence</li>
                <li>Technical RFQ</li>
              </ol>
              <b>Context-preserving handoff</b>
            </section>
          </div>
          <p className="case-source">
            Benchmark: CNP NISO / NIS / NISF public product page, accessed
            2026-07-29. Structural audit only; no brand assets or copy
            reproduced.
          </p>
        </div>
        <CardFooter text="Problem reframed: catalogue page → purchase-decision interface" />
      </article>

      <article className="case-card case-card-2" data-card="02">
        <CardHeader number="02" label="BUYER QUESTIONS" />
        <div className="case-card-body">
          <p className="case-kicker">
            The information architecture starts here.
          </p>
          <h1>Seven questions an overseas technical buyer needs answered.</h1>
          <ol className="question-list">
            {buyerQuestions.map((question, index) => (
              <li key={question}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <p>{question}</p>
              </li>
            ))}
          </ol>
          <div className="case-callout">
            <strong>UX decision</strong>
            <p>
              Organize the page by decisions, not by the order in which an
              engineering brochure happens to describe the product.
            </p>
          </div>
        </div>
        <CardFooter text="Primary user: mechanical / HVAC engineer or technical buyer" />
      </article>

      <article className="case-card case-card-3 case-card-dark" data-card="03">
        <CardHeader number="03" label="TRUTH CONTRACT" />
        <div className="case-card-body">
          <p className="case-kicker">Evidence before interface.</p>
          <h1>What the prototype knows—and where it must stop.</h1>
          <div className="truth-grid">
            <section>
              <span className="truth-status truth-known">KNOWN</span>
              <h2>50 Hz concept dataset</h2>
              <p>
                Three typed model curves with Q–H, efficiency, NPSHr and power.
              </p>
            </section>
            <section>
              <span className="truth-status truth-reference">REFERENCE</span>
              <h2>ISO / HI definitions</h2>
              <p>
                Design language and operating-region meaning—not certification.
              </p>
            </section>
            <section>
              <span className="truth-status truth-review">REVIEW</span>
              <h2>60 Hz performance</h2>
              <p>No curve supplied. The UI returns Engineering review.</p>
            </section>
            <section>
              <span className="truth-status truth-missing">NOT CLAIMED</span>
              <h2>Approval or outcome</h2>
              <p>
                No real selection, certificate, sales uplift, price or lead
                time.
              </p>
            </section>
          </div>
          <div className="truth-rule">
            <span>FAIL-CLOSED RULE</span>
            <strong>
              Missing evidence changes the UI state—not just a footnote.
            </strong>
          </div>
        </div>
        <CardFooter text="Illustrative concept data — not for engineering selection" />
      </article>

      <article className="case-card case-card-4" data-card="04">
        <CardHeader number="04" label="SELECTION LOGIC" />
        <div className="case-card-body">
          <p className="case-kicker">
            Golden trace · 40 m³/h · 45 m · 50 Hz · 20 °C
          </p>
          <h1>The shortlist shows the reason, not just the answer.</h1>
          <div className="trace-line">
            <div>
              <span>INPUT</span>
              <strong>40 / 45</strong>
              <small>m³/h / m</small>
            </div>
            <i aria-hidden="true">→</i>
            <div>
              <span>FILTER</span>
              <strong>2 / 3</strong>
              <small>curves eligible</small>
            </div>
            <i aria-hidden="true">→</i>
            <div>
              <span>RESULT</span>
              <strong>NX 65</strong>
              <small>best concept match</small>
            </div>
          </div>
          <div className="score-table">
            {scoreRows.map(([name, score, meaning]) => (
              <div key={name}>
                <span>{name}</span>
                <strong>{score}</strong>
                <p>{meaning}</p>
              </div>
            ))}
          </div>
          <p className="excluded-note">
            <strong>NX 50-32-160 excluded:</strong> interpolated head is below
            the required 45 m. Filtering happens before scoring.
          </p>
        </div>
        <CardFooter text="Policy v1 is deterministic, versioned and independently tested" />
      </article>

      <article className="case-card case-card-5 case-card-dark" data-card="05">
        <CardHeader number="05" label="PERFORMANCE VIEW" />
        <div className="case-card-body">
          <p className="case-kicker">
            One selected model · one shared data record.
          </p>
          <h1>Turn the curve into a decision checkpoint.</h1>
          <StaticCurve />
          <div className="curve-proof-grid">
            <div>
              <span>Curve head</span>
              <strong>49.2 m</strong>
            </div>
            <div>
              <span>Efficiency</span>
              <strong>77%</strong>
            </div>
            <div>
              <span>NPSHr</span>
              <strong>3.0 m</strong>
            </div>
            <div>
              <span>Shaft power</span>
              <strong>8.0 kW</strong>
            </div>
          </div>
          <div className="case-callout case-callout-dark">
            <strong>Accessible by design</strong>
            <p>
              The visual is paired with an expandable data table. Units convert
              values and axes, not labels alone.
            </p>
          </div>
        </div>
        <CardFooter text="POR is model-specific and explicitly illustrative" />
      </article>

      <article className="case-card case-card-6" data-card="06">
        <CardHeader number="06" label="TECHNICAL RFQ" />
        <div className="case-card-body">
          <p className="case-kicker">
            The selection should survive the handoff.
          </p>
          <h1>
            Replace a generic contact form with a review-ready technical brief.
          </h1>
          <div className="rfq-flow">
            <section>
              <span>STEP 01</span>
              <h2>Selected duty</h2>
              <p>Model · flow · head · frequency · fluid · temperature</p>
            </section>
            <section>
              <span>STEP 02</span>
              <h2>System &amp; configuration</h2>
              <p>
                NPSHa · suction · material · seal · motor · standards · file
              </p>
            </section>
            <section>
              <span>STEP 03</span>
              <h2>Contact &amp; stage</h2>
              <p>Company context and explicit local-demo consent</p>
            </section>
          </div>
          <div className="handoff-summary">
            <span>DETERMINISTIC HANDOFF</span>
            <pre>{`Model: NX 65-40-200
Duty: 40 m³/h at 45 m
Frequency: 50 Hz
Installation: Germany
Status: local demo only`}</pre>
          </div>
          <ul className="boundary-list">
            <li>No CRM or email integration</li>
            <li>No contact or attachment persistence</li>
            <li>Client + route schema validation</li>
          </ul>
        </div>
        <CardFooter text="Output: copyable and downloadable technical summary" />
      </article>

      <article className="case-card case-card-7" data-card="07">
        <CardHeader number="07" label="PROOF & POSITIONING" />
        <div className="case-card-body">
          <p className="case-kicker">Not a visual redesign exercise.</p>
          <h1>
            A working proof that engineering detail can become buyer decision
            information.
          </h1>
          <div className="proof-metrics">
            <div>
              <strong>50 Hz</strong>
              <span>deterministic shortlist</span>
            </div>
            <div>
              <strong>60 Hz</strong>
              <span>fail-closed review</span>
            </div>
            <div>
              <strong>3 steps</strong>
              <span>context-preserving RFQ</span>
            </div>
            <div>
              <strong>0</strong>
              <span>serious / critical axe issues</span>
            </div>
          </div>
          <div className="positioning-statement">
            <span>POSITIONING</span>
            <p>
              I restructure overseas product pages for Chinese electromechanical
              manufacturers—so complex parameters become information buyers can
              understand, shortlist and carry into a technical inquiry.
            </p>
          </div>
          <div className="case-final-actions">
            <Link href="/">Open interactive product page</Link>
            <span>
              No real engineering selection or inquiry-growth claim is made.
            </span>
          </div>
        </div>
        <CardFooter text="AsterFlow NX Series · complete concept evidence flow" />
      </article>
    </main>,
  );
}
